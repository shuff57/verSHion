import { createRequire } from 'module';
import { loadPlaywright, fileUrl, outDir, root } from './_env.mjs';
const { chromium } = loadPlaywright();
const out = outDir + '/', tag = process.argv[2] || 'a';
const b = await chromium.launch(); const errs = [];
const go = async (vp, scheme, name) => {
  const c = await b.newContext({ viewport: vp, colorScheme: scheme }); const p = await c.newPage(); p.on('pageerror', e => errs.push(String(e)));
  await p.goto(fileUrl('dist/site/test.html') + '?form=A&teacher=1'); await p.waitForTimeout(2300);
  await p.screenshot({ path: out + `${tag}-${name}-welcome.png` });
  await p.fill('#nm', 'Maya'); await p.fill('#cd', 'P4'); await p.click('#go'); await p.waitForTimeout(200);
  await p.screenshot({ path: out + `${tag}-${name}-instr.png` });
  await p.click('#go'); await p.waitForTimeout(200);
  await p.evaluate(() => { const S = window.__sd.S; S.idx = S.seq.findIndex(s => s.id === 'T2'); window.__sd.render(); });
  await p.waitForTimeout(150); await p.screenshot({ path: out + `${tag}-${name}-item.png` });
  await p.evaluate(() => { const S = window.__sd.S; const i = S.seq.findIndex(s => s.kind === 'intro' && s.block === 'G'); S.idx = i; window.__sd.render(); });
  await p.waitForTimeout(150); await p.screenshot({ path: out + `${tag}-${name}-intro.png` });
  await p.evaluate(() => { const S = window.__sd.S; S.idx = S.seq.length; S.finished = true; window.__sd.render(); });
  await p.waitForTimeout(2300); await p.screenshot({ path: out + `${tag}-${name}-end.png` });
  await c.close();
};
await go({ width: 900, height: 900 }, 'light', 'd'); await go({ width: 390, height: 800 }, 'light', 'm'); await go({ width: 800, height: 800 }, 'dark', 'dk');
// viewer
const c = await b.newContext({ viewport: { width: 1200, height: 900 } }); const p = await c.newPage(); p.on('pageerror', e => errs.push(String(e)));
await p.goto(fileUrl('dist/site/viewer.html')); await p.waitForTimeout(300); await p.screenshot({ path: out + `${tag}-v-empty.png` });
await p.click('[data-act="sample"]'); await p.waitForTimeout(800); await p.screenshot({ path: out + `${tag}-v-students.png`, fullPage: true });
await p.click('[data-tab="class"]'); await p.waitForTimeout(200); await p.screenshot({ path: out + `${tag}-v-class.png`, fullPage: true });
console.log('errors', errs); await b.close();
