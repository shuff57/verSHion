import { loadPlaywright, root, outDir } from './_env.mjs';
import path from 'path'; import { pathToFileURL } from 'url';
const { chromium } = loadPlaywright();
const out = process.argv[2] || outDir;
const b = await chromium.launch();
async function frames(file, times, scheme, w, h, bg) {
  const c = await b.newContext({ viewport: { width: w, height: h }, colorScheme: scheme }); const p = await c.newPage();
  const errs = []; p.on('pageerror', e => errs.push(String(e)));
  await p.goto(pathToFileURL(path.join(root, 'brand', file)).href);
  await p.evaluate((bg) => { document.documentElement.style.background = bg; }, bg);
  for (const t of times) {
    await p.evaluate((t) => { const s = document.documentElement; s.pauseAnimations(); s.setCurrentTime(t); }, t);
    await p.waitForTimeout(60);
    await p.screenshot({ path: `${out}/logo-${file.replace('.svg', '')}-${scheme}-${t}.png` });
  }
  await c.close(); return errs;
}
const e = [];
e.push(...await frames('tenshion-logo.svg', [0, 0.22, 0.45, 0.9, 1.35, 2.4], 'light', 900, 320, '#E6E4DF'));
e.push(...await frames('tenshion-logo.svg', [0.45, 2.4], 'dark', 900, 320, '#1F1E1C'));
e.push(...await frames('tenshion-logo-on-board.svg', [0, 0.45, 2.4], 'light', 900, 320, '#E6E4DF'));
e.push(...await frames('tenshion-mark.svg', [0, 0.45, 0.9, 2.4], 'light', 512, 512, '#E6E4DF'));
e.push(...await frames('tenshion-logo-clean.svg', [2.4], 'light', 900, 320, '#E6E4DF'));
e.push(...await frames('tenshion-logo-static.svg', [0], 'light', 900, 320, '#E6E4DF'));
console.log('errors', e); await b.close();
