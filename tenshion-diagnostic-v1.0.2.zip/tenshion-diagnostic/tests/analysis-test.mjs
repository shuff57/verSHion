import { createRequire } from 'module';
import fs from 'fs';
const require = createRequire(import.meta.url);
const A = require('../src/analysis.js');
const dir = new URL('./out/', import.meta.url).pathname;

// The sims click in ~50 ms; scale each profile's clock to something human so rapid-response logic is exercised honestly.
const scale = { strong: 250, needsEntry: 250, fearful: 250, gap: 250, checkedOut: 15 };
function rescale(res, f) {
  const T = ['enteredAt','ms','firstActionMs','firstKeyMs','choiceMs','firstMs','doneMs','t'];
  const walk = (o) => { if (Array.isArray(o)) o.forEach(walk); else if (o && typeof o === 'object') { for (const k of Object.keys(o)) { if (T.includes(k) && typeof o[k] === 'number') o[k] = Math.round(o[k] * f); else walk(o[k]); } } };
  walk(res.records); return res;
}
const expect = { strong: 'ok', needsEntry: 'unable', fearful: 'unable', gap: 'knowledge', checkedOut: 'unreliable' };
const expectId = { needsEntry: 'entry', fearful: 'fear', gap: null, checkedOut: null };
let bad = 0;
const results = Object.keys(scale).map(k => rescale(JSON.parse(fs.readFileSync(dir + k + '.json', 'utf8')), scale[k]));
const students = A.merge(results);
const sums = students.map(s => { const m = A.summarize(s); return { m, c: A.classify(m) }; });
for (const s of sums) {
  const k = Object.keys(scale).find(x => x.toLowerCase() === s.m.name.toLowerCase());
  const ok = s.c.bucket === expect[k] && (!expectId[k] || (s.c.primary && s.c.primary.id === expectId[k]));
  if (!ok) bad++;
  console.log((ok ? 'PASS' : 'FAIL'), s.m.name.padEnd(11), s.c.bucket.padEnd(10), (s.c.primary ? s.c.primary.id : '-').padEnd(8), s.c.confidence.padEnd(9), '| signals:', s.c.signals.map(x => x.id + ':' + x.strength).join(' ') || '-');
  if (process.argv[2] === '-v') { console.log('   ', s.c.primary && s.c.primary.evidence); s.c.notes.forEach(n => console.log('    note:', n)); }
}
const cs = A.classSummary(sums);
console.log('class buckets', JSON.stringify(cs.buckets), 'items', cs.items.length, 'reading', JSON.stringify(cs.reading));
console.log('start cmp', JSON.stringify(cs.comparisons.start), 'steps cmp', JSON.stringify(cs.comparisons.steps));
console.log('csv rows', A.studentsCsv(sums).split('\n').length, A.itemsCsv(sums).split('\n').length);
// merge: two sittings for one student combine, preview flag carried, latest record wins
const a = JSON.parse(JSON.stringify(results[0])); const b = JSON.parse(JSON.stringify(results[0]));
a.blocks = 'ABC'; a.records = a.records.slice(0, 20); b.blocks = 'DGH'; b.startedAt = '2999-01-01T00:00:00Z'; b.records = b.records.slice(20); b.teacherMode = true;
const mm = A.merge([b, a])[0]; console.log('merged files', mm.files, 'records', mm.order.length, 'preview', mm.preview);
if (mm.files !== 2 || mm.order.length !== results[0].records.length) { bad++; console.log('FAIL merge'); }
// code round trip (same encoding the page uses)
const zlib = require('zlib');
const code = 'SD1.' + zlib.gzipSync(JSON.stringify(results[0])).toString('base64url');
const dec = await A.decodeCode(code); if (dec.student.name !== results[0].student.name) { bad++; console.log('FAIL code roundtrip'); } else console.log('code round trip OK (' + code.length + ' chars)');
console.log(bad ? bad + ' FAILURES' : 'analysis OK'); process.exit(bad ? 1 : 0);
