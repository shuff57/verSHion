import { createRequire } from 'module';
const require = createRequire(import.meta.url);
const B = require('../src/bank.js');
let bad = 0;
const ok = (c, m) => { if (!c) { bad++; console.log('FAIL', m); } };

// independent recomputation of every keyed answer
const chk = (id, v) => ok(B.check(B.byId(id), v), id + ' accepts ' + v);
chk('A1', 36/4+5); chk('A2', 60); chk('A3', 30); chk('A4', 72); chk('A5', 14-4); chk('A6', 21);
chk('A7', 1); chk('A8', 8); chk('A9', (5+9+7+11+13)/5);
// tasks: first term + diff*(n-1)
const lin = (a, d, n) => a + d*(n-1);
chk('T1', lin(5,3,25)); chk('T2', lin(6,4,30)); chk('T3', lin(7,5,30)); chk('T4', lin(9,2,45));
[['T1',5,3,[4,5]],['T2',6,4,[4,5]],['T3',7,5,[4,5]],['T4',9,2,[4,5]]].forEach(([id,a,d,ns]) => {
  const f = B.byId(id).scaffold.fields; ns.forEach((n,i) => ok(B.check({type:'num',accept:f[i].accept}, lin(a,d,n)), id+' scaffold '+n));
});
chk('C1', 24*0.75); chk('C2', 3/12*20); chk('C3', 15+0.1*120); chk('C4', 48/6*10); chk('C5', Math.ceil((200-50)/15)); chk('C6', 28-28*3/7);
// deals: first n where totals match
[['D1',24,2,6],['D2',40,3,8],['D3',45,4,9],['D4',60,5,10]].forEach(([id,f,a,b]) => {
  let n = 0; while (f + a*n !== b*n) { n++; if (n > 100) break; } chk(id, n);
  ok(f + a*n === b*n, id+' break-even exact');
});
chk('F1', 18-6); chk('F3', 1);
let x = 2; for (let i=0;i<4;i++) x = x*2+1; chk('F2', x);
chk('F4', 6); chk('E1', 42); chk('E2', 41); chk('E3', 12*11/2);
chk('X1', 2); chk('X2', 5050); chk('X3', 2**3); chk('X4', 2**5);
// E2: brute force
let e2=null; for (let a=-99;a<99;a+=2){ if (a+(a+2)+(a+4)===117) e2=a+4; } ok(e2===41,'E2 brute');
// E4 solutions & rejections
ok(B.check(B.byId('E4'), '123+4-5+67-89'), 'E4 solution 1');
ok(B.check(B.byId('E4'), '123 - 45 - 67 + 89'), 'E4 solution 2');
ok(!B.check(B.byId('E4'), '12+34-5+6789'), 'E4 example is not 100');
ok(!B.evalDigits('12345678').ok, 'E4 missing digit rejected');
ok(!B.evalDigits('1+2+3+4+5+6+7+8+9+').ok, 'trailing op rejected');
ok(B.evalDigits('12+34-5+6789').value === 12+34-5+6789, 'E4 evaluates');
// answer parsing
ok(B.toNumber('$72') === 72 && B.toNumber('72 dollars') === 72 && B.toNumber('x = 8') === 8 && B.toNumber('1,000') === 1000, 'toNumber basics');
ok(B.toNumber('3/4') === 0.75 && B.toNumber('−5') === -5, 'toNumber frac/minus');
ok(isNaN(B.toNumber('')) && isNaN(B.toNumber('idk')), 'toNumber junk');
// duplicate answers inside a block would let guessing look like knowledge
['A','B','C','D','E','F','K'].forEach(b => { const ans = B.ITEMS.filter(i=>i.block===b && i.accept).map(i=>i.accept[0]); ok(new Set(ans).size === ans.length, 'unique answers in '+b+': '+ans); });

// floor items
chk('FL1', 12); chk('FL2', 6); chk('FL3', 18); chk('FL4', 17);

// G: recompute every option's meaning from scratch
const text = (o) => o.t.replace(/<[^>]+>/g,'').replace(/⁄|&frasl;/g,'/').replace(/\$/g,'');
const find = (opts, kind) => opts.filter(o => o.kind === kind).map(text);
const g = id => B.byId(id);
ok(find(g('G1').final.options,'correct')[0]==='66' && 80*0.75*1.1 === 66.00000000000001 || Math.abs(80*0.75*1.1-66)<1e-9, 'G1 final 66');
ok(find(g('G1').final.options,'stopEarly')[0]==='60', 'G1 stopEarly = sale price');
ok(Math.abs(80*(1-0.25+0.10)-68)<1e-9 && find(g('G1').final.options,'combine')[0]==='68', 'G1 combine = 68');
ok(80*1.1 === 88 && find(g('G1').final.options,'wrongBase')[0]==='88', 'G1 wrongBase = 88');
ok(80*0.25===20 && find(g('G1').steps[0].options,'correct')[0]==='20', 'G1 step1');
ok(80-20===60 && find(g('G1').steps[1].options,'correct')[0]==='60', 'G1 step2');
ok(60*0.1===6.000000000000001 || Math.abs(60*0.1-6)<1e-9, 'G1 step3'); ok(find(g('G1').steps[2].options,'correct')[0]==='6','G1 step3 key');
ok(find(g('G1').steps[2].options,'wrongBase')[0]==='8','G1 step3 wrongBase = 10% of 80');
ok(find(g('G2').final.options,'correct')[0]==String(360/12+3), 'G2 final');
ok(find(g('G2').final.options,'skipStep')[0]==String(180/12+3), 'G2 forgot 2nd copy');
ok(find(g('G2').final.options,'stopEarly')[0]==String(360/12), 'G2 forgot warm-up');
ok(find(g('G2').steps[0].options,'correct')[0]==='360' && find(g('G2').steps[1].options,'correct')[0]==String(360/12), 'G2 steps');
ok(find(g('G3').final.options,'correct')[0]==String(14*7-12*5), 'G3 final');
ok(find(g('G3').final.options,'wrongOp').includes(String(2*(12+5))), 'G3 perimeter');
ok(find(g('G3').steps[1].options,'correct')[0]==String(14*7) && find(g('G3').steps[2].options,'correct')[0]==String(12*5), 'G3 steps');
ok(find(g('G4').final.options,'correct')[0]==String(30*3/5/2), 'G4 final');
ok(find(g('G4').final.options,'skipStep')[0]==String(30/2), 'G4 halved the mix');
ok(find(g('G4').final.options,'wrongOp')[0]==String(30*2/5/2), 'G4 used white');
ok(find(g('G4').steps[1].options,'correct')[0]===String(30*3/5), 'G4 step2');
['G1','G2','G3','G4'].forEach(id => {
  const it = g(id); const all = it.steps.concat([it.final]);
  all.forEach((st,i) => ok(st.options.filter(o=>o.kind==='correct').length===1 && st.options.length===4, id+' step '+i+' has exactly one correct of 4'));
  ok(new Set(it.final.options.map(o=>o.t)).size===4, id+' distinct final options');
  ok(it.final.options.filter(o=>/stopEarly|skipStep/.test(o.kind)).length>=1, id+' has a skipped-step distractor');
});
const pos = ['G1','G2','G3','G4'].map(id=>g(id).final.options.findIndex(o=>o.kind==='correct'));
ok(new Set(pos).size>=3, 'G final correct positions vary: '+pos);
const spos = []; ['G1','G2','G3','G4'].forEach(id=>g(id).steps.forEach(st=>spos.push(st.options.findIndex(o=>o.kind==='correct')))); ok(new Set(spos).size>=3,'G step correct positions vary: '+spos);
ok(B.check(g('G1'), 2) && !B.check(g('G1'), 0), 'check() on steps item');

// K: recompute
const cost = n => 60 + 5*n, rev = n => 12*n;
const K = B.byId('K1').parts; const kv = {};
K.forEach(p => kv[p.key] = p.accept[0]);
ok(+kv.a===cost(40) && +kv.b===rev(40) && +kv.c===rev(40)-cost(40), 'K a-c');
let d=1; while (rev(d) <= cost(d)) d++; ok(+kv.d===d, 'K d smallest profitable = '+d);
let e=1; while (rev(e)-cost(e) !== 500 && e<1000) e++; ok(+kv.e===e, 'K e exact $500 = '+e);
ok(new Set(Object.values(kv)).size===5, 'K answers distinct');

// H: independent solvers
const h = id => B.byId(id);
// H2 ordering: enumerate permutations
const perms = a => a.length<2?[a]:a.flatMap((x,i)=>perms([...a.slice(0,i),...a.slice(i+1)]).map(p=>[x,...p]));
const valid = perms(['Ana','Ben','Cal','Dee']).filter(o => o.indexOf('Ana')<o.indexOf('Ben') && o.indexOf('Cal')>o.indexOf('Ben') && o.indexOf('Dee')<o.indexOf('Ana'));
ok(valid.length===1 && h('H2').options[h('H2').answer]===valid[0][2], 'H2 unique order, third = '+valid[0][2]);
// H6 knights and knaves: truth-teller true statements, liar false statements
const sols=[]; for (const A of [true,false]) for (const Bn of [true,false]) {
  const avaSays = !Bn; const benSays = A && Bn;
  if (avaSays===A && benSays===Bn) sols.push({A,B:Bn}); }
ok(sols.length===1 && sols[0].A===true && sols[0].B===false && /Ava tells the truth; Ben lies/.test(h('H6').options[h('H6').answer]), 'H6 unique solution');
// H3 Wason: card must be flipped iff a hidden side could falsify "vowel -> even"
const vowel = c => 'AEIOU'.includes(c), even = c => /^\d+$/.test(c) && +c%2===0;
const must = ['E','K','4','7'].filter(c => /[A-Z]/.test(c) ? vowel(c) : !even(c));
ok(must.join()==='E,7' && /E and 7/.test(h('H3').options[h('H3').answer]), 'H3 must flip E and 7');
// H5: first step that is false
const lhs = (x)=>2*(x+3); const stepOK = [true,false,false]; // step1 "2x+3=14" is not equivalent to 2(x+3)=14
ok(/Step 1/.test(h('H5').options[h('H5').answer]) && 2*(5.5+3)!==14 && 2*4+3*2===14 , 'H5 error is step 1 (true solution x=4)');
ok(/other ways/.test(h('H4').options[h('H4').answer]), 'H4 key is the confounding reason');
ok(/not in Ms/.test(h('H1').options[h('H1').answer].replace('&rsquo;',"'").replace("Ortega's","Ortega's")) || /is not in/.test(h('H1').options[h('H1').answer]), 'H1 key is modus tollens');
['H1','H2','H3','H4','H5','H6'].forEach(id => ok(h(id).kinds.filter(k=>k==='correct').length===1 && h(id).options.length===4, id+' one correct of 4'));
const hp = ['H1','H2','H3','H4','H5','H6'].map(id=>h(id).answer); ok(new Set(hp).size>=3, 'H correct positions vary: '+hp);

// sequences
for (const f of ['A','B']) for (const len of ['full','short']) {
  const s = B.sequence(f, len); const items = s.filter(k=>k.kind==='item');
  console.log(f, len, 'screens', s.length, 'items', items.length);
  ok(new Set(items.map(i=>i.id)).size === items.length, 'no duplicate item ids '+f+len);
  const cnt = {}; items.filter(i=>i.block==='C').forEach(i=>cnt[i.cond]=(cnt[i.cond]||0)+1);
  console.log('  stakes', JSON.stringify(cnt), ' B:', items.filter(i=>i.block==='B').map(i=>i.id+':'+i.cond).join(' '), ' D:', items.filter(i=>i.block==='D').map(i=>i.id+':'+i.cond).join(' '));
}
console.log(bad ? bad+' FAILURES' : 'bank OK');
process.exit(bad?1:0);
