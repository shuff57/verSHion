import { createRequire } from 'module';
import fs from 'fs';
const req2 = createRequire(import.meta.url);
import { loadPlaywright, fileUrl, outDir, root } from './_env.mjs';
const { chromium } = loadPlaywright();
const A = req2('../src/analysis.js'), B = req2('../src/bank.js');
const out = outDir + '/';
let bad = 0; const ok = (c, m) => { console.log(c ? 'PASS' : 'FAIL', m); if (!c) bad++; };
const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 900, height: 900 } });
const page = await ctx.newPage();
const errs = []; page.on('pageerror', e => errs.push(String(e)));
await page.goto(fileUrl('dist/site/test.html') + '?form=B&blocks=ABCS');
await page.fill('#nm', 'Jordan'); await page.fill('#cd', 'P4'); await page.click('#go'); await page.click('#go');
const idxOf = () => page.evaluate(() => window.__sd.S.idx);
const i0 = await idxOf();
// answer R1 then FL1 so there is history to try to go back to
await (await page.$$('.opt'))[3].click(); await page.click('#next');
await page.click('#go');
await page.fill('#ans', '12'); await page.click('#next');
const before = await idxOf();
// 1. back button
await page.evaluate(() => history.back()); await page.waitForTimeout(150);
ok(await idxOf() === before, 'browser Back does not change the screen');
ok((await page.evaluate(() => window.__sd.S.backAttempts)) === 1, 'Back attempt is logged');
ok(await page.isVisible('.toast'), 'student sees a short notice');
ok(!(await page.$('text=/^Back$/')), 'no on-page Back button exists');
// 2. reload resumes at the same screen, no earlier screen reachable
await page.reload(); await page.waitForTimeout(100);
ok(await page.isVisible('text=Welcome back, Jordan'), 'reload shows resume screen');
await page.click('#go');
ok(await idxOf() === before, 'resume lands on the same screen');
ok((await page.evaluate(() => window.__sd.S.reloads)) === 1, 'reload is logged');
// 3. the stakes banner follows the form (Form B: C1 = credit)
const idxC1 = await page.evaluate(() => window.__sd.S.seq.findIndex(s => s.id === 'C1'));
await page.evaluate((i) => { window.__sd.S.idx = i; window.__sd.render(); }, idxC1);
ok((await page.textContent('.banner')).includes('participation points'), 'Form B C1 shows the "counts" note');
// 4. jump to survey, finish, check partial-sitting result + code
const idxS = await page.evaluate(() => window.__sd.S.seq.findIndex(s => s.kind === 'survey'));
await page.evaluate((i) => { window.__sd.S.idx = i; window.__sd.render(); }, idxS);
await page.click('#go');
ok(await page.isVisible('text=All done, Jordan'), 'end screen shown after the survey');
const [dl] = await Promise.all([page.waitForEvent('download'), page.click('#dl')]);
ok(/start_jordan_p4_B-abcs\.json/.test(dl.suggestedFilename()), 'download name carries student, class, form, sitting: ' + dl.suggestedFilename());
const path = out + 'behavior.json'; await dl.saveAs(path); const res = JSON.parse(fs.readFileSync(path, 'utf8'));
ok(res.records.some(r => r.id === 'FL1' && r.correct === true), 'FL1 recorded correct');
ok(res.records.find(r => r.id === 'R1').passed === true, 'R1 reading check recorded as passed');
ok(res.backAttempts === 1 && res.reloads === 1 && res.blocks === 'ABCS' && res.form === 'B', 'result carries backAttempts, reloads, blocks, form');
const code = await page.evaluate((j) => window.__sd.makeCode(j), JSON.stringify(res));
const round = await A.decodeCode(code);
ok(round.student.name === 'Jordan' && round.records.length === res.records.length, 'copied results code decodes to the same data (' + code.length + ' chars)');
// 5. a finished session survives reload and still offers the download
await page.reload(); await page.waitForTimeout(100);
ok(await page.isVisible('#dl'), 'finished session still offers download after reload');
// 6. mobile layout
const m = await browser.newContext({ viewport: { width: 390, height: 800 }, isMobile: true, hasTouch: true });
const mp = await m.newPage(); mp.on('pageerror', e => errs.push(String(e)));
await mp.goto(fileUrl('dist/site/test.html') + '?form=A&teacher=1'); await mp.fill('#nm', 'Phone'); await mp.click('#go'); await mp.click('#go');
for (const id of ['T2', 'C1']) {
  await mp.evaluate((id) => { const S = window.__sd.S; S.idx = S.seq.findIndex(s => s.id === id); window.__sd.render(); }, id);
  if (id === 'T2') { await mp.fill('.sf >> nth=0', '18'); await mp.fill('.sf >> nth=1', '22'); await mp.click('#sfgo'); }
  await mp.screenshot({ path: out + 'm-' + id + '.png' });
  const overflow = await mp.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 1);
  ok(!overflow, 'no horizontal scroll on phone for ' + id);
}
// 6b. hash-token links
const hp = await (await browser.newContext()).newPage(); hp.on('pageerror', e => errs.push(String(e)));
await hp.goto(fileUrl('dist/site/test.html') + '#form-B_len-short_blocks-DGKH_class-P4');
ok(await hp.inputValue('#cd') === 'P4', 'hash token class-P4 pre-fills class');
await hp.fill('#nm', 'Hash'); await hp.click('#go'); await hp.click('#go');
const hs = await hp.evaluate(() => ({ f: window.__sd.S.form, b: window.__sd.S.blocks, l: window.__sd.S.len, ids: window.__sd.S.seq.filter(s => s.id).map(s => s.id[0]).filter((v, i, a) => a.indexOf(v) === i).join('') }));
ok(hs.f === 'B' && hs.b === 'DGKH' && hs.l === 'short', 'hash tokens set form/blocks/len: ' + JSON.stringify(hs));
// 7. dark mode renders
const d = await browser.newContext({ viewport: { width: 800, height: 700 }, colorScheme: 'dark' });
const dp = await d.newPage(); await dp.goto(fileUrl('dist/site/test.html')); await dp.screenshot({ path: out + 'dark.png' });
ok(errs.length === 0, 'no page errors: ' + JSON.stringify(errs));
await browser.close();
console.log(bad ? bad + ' FAILURES' : 'behavior OK'); process.exit(bad ? 1 : 0);
