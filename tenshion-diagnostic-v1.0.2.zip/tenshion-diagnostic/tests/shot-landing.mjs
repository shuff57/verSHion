import { createRequire } from 'module'; import fs from 'fs';
import { loadPlaywright, fileUrl, outDir, root } from './_env.mjs';
const { chromium } = loadPlaywright();
const out = outDir + '/';
const b = await chromium.launch(); const errs = [];
for (const [name, vp, scheme] of [['d', { width: 1280, height: 900 }, 'light'], ['m', { width: 390, height: 844 }, 'light'], ['dk', { width: 1100, height: 900 }, 'dark']]) {
  const c = await b.newContext({ viewport: vp, colorScheme: scheme }); const p = await c.newPage(); p.on('pageerror', e => errs.push(String(e)));
  await p.goto(fileUrl('dist/site/index.html')); await p.waitForTimeout(3200);
  await p.screenshot({ path: out + 'land-' + name + '-top.png' });
  await p.screenshot({ path: out + 'land-' + name + '-full.png', fullPage: true });
  const ov = await p.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  console.log(name, 'horizontal overflow px:', ov);
  if (name === 'd') { await p.fill('#f-class', 'P4 !'); await p.selectOption('#f-form', 'B'); await p.selectOption('#f-len', 'short'); await p.selectOption('#f-sit', 'DGKH'); console.log(await p.inputValue('#f-url')); }
}
console.log('errors', errs); await b.close();
