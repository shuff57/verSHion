// Build the viewer's built-in sample class from the simulated runs: realistic clock scaling, friendly names, gzip codes.
import { createRequire } from 'module';
import fs from 'fs'; import zlib from 'zlib';
const require = createRequire(import.meta.url);
const dir = new URL('./out/', import.meta.url).pathname;
const spec = { strong: ['Sample: starts and persists', 250], needsEntry: ['Sample: needs an entry point', 250], fearful: ['Sample: fear of being wrong', 250], gap: ['Sample: knowledge gap', 250], checkedOut: ['Sample: rushing', 15] };
const T = ['enteredAt','ms','firstActionMs','firstKeyMs','choiceMs','firstMs','doneMs','t'];
const codes = Object.entries(spec).map(([k, [name, f]]) => {
  const res = JSON.parse(fs.readFileSync(dir + k + '.json', 'utf8'));
  const walk = (o) => { if (Array.isArray(o)) o.forEach(walk); else if (o && typeof o === 'object') for (const key of Object.keys(o)) { if (T.includes(key) && typeof o[key] === 'number') o[key] = Math.round(o[key] * f); else walk(o[key]); } };
  walk(res.records); res.student = { name, code: 'Sample' }; res.activeMs = res.records.reduce((s, r) => s + (r.ms || 0), 0);
  return 'SD1.' + zlib.gzipSync(JSON.stringify(res)).toString('base64url');
});
fs.writeFileSync(new URL('../src/sample-codes.json', import.meta.url), JSON.stringify(codes));
console.log('sample codes', codes.map(c => c.length));
