// Drive the real student test in headless Chromium with scripted student "profiles" and save the result files.
// Usage: node tests/sim.mjs [outDir]
import { createRequire } from 'module';
import fs from 'fs';
const B = createRequire(import.meta.url)('../src/bank.js');
import { loadPlaywright, fileUrl, outDir, root } from './_env.mjs';
const { chromium } = loadPlaywright();

const OUT = outDir;
fs.mkdirSync(OUT, { recursive: true });
const URL = fileUrl('dist/site/test.html');

// A profile decides, per item, what a simulated student does.
// knows(tag)->bool; start(kind)->bool; etc. All times are scaled down so the run is quick.
const profiles = {
  strong:   { name: 'Strong',   form: 'A', readOk: [1,1,1], knows: () => true,  startOpen: true,  startForced: true,  fear: false, persist: 1.0, extras: 2, trapSkips: false, rapid: false },
  needsEntry:{ name: 'NeedsEntry', form: 'A', readOk: [1,1,1], knows: () => true,  startOpen: false, startForced: true,  fear: false, persist: 0.8, extras: 0, trapSkips: true, rapid: false },
  fearful:  { name: 'Fearful',  form: 'B', readOk: [1,1,1], knows: () => true,  startOpen: true,  startForced: true,  fear: true,  persist: 0.5, extras: 0, trapSkips: false, rapid: false },
  gap:      { name: 'Gap',      form: 'A', readOk: [1,1,1], knows: (t) => t === 'floor', startOpen: true, startForced: true, fear: false, persist: 0.6, extras: 0, trapSkips: false, rapid: false },
  checkedOut:{ name: 'CheckedOut', form: 'B', readOk: [0,0,0], knows: () => true, startOpen: false, startForced: false, fear: false, persist: 0, extras: 0, trapSkips: false, rapid: true },
};

async function run(browser, key, p, extraQuery = '') {
  const ctx = await browser.newContext({ viewport: { width: 900, height: 1000 } });
  const page = await ctx.newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e))); page.on('console', m => { if (m.type() === 'error' && !/ERR_TUNNEL_CONNECTION_FAILED|ERR_NAME_NOT_RESOLVED/.test(m.text())) errs.push(m.text()); });
  await page.goto(`${URL}?form=${p.form}&len=short${extraQuery}`);
  await page.fill('#nm', p.name); await page.fill('#cd', 'SIM'); await page.click('#go');
  await page.click('#go'); // instructions -> begin

  let guard = 0, rc = 0;
  while (guard++ < 400) {
    const sd = await page.evaluate(() => { const S = window.__sd.S; return { fin: S.finished, idx: S.idx, sc: S.seq[S.idx] || null }; });
    if (sd.fin) break;
    const sc = sd.sc;
    if (!sc) { await page.waitForTimeout(30); continue; }
    if (sc.kind === 'intro') { await page.click('#go'); continue; }
    if (sc.kind === 'survey') {
      if (!p.rapid) {
        await page.evaluate(() => { document.querySelectorAll('table.likert tbody tr').forEach((tr, i) => { const r = tr.querySelectorAll('input'); r[(i % 5)].click(); }); document.querySelectorAll('.why input')[1].click(); });
        await page.fill('#open', 'sim note');
      }
      await page.click('#go'); continue;
    }
    if (sc.kind === 'extras') {
      for (let i = 0; i < p.extras; i++) {
        const btn = await page.$('.xcard button:not([disabled])'); if (!btn) break;
        await btn.click();
        const it = await page.evaluate(() => 1);
        if (await page.$('#xa')) await page.fill('#xa', '5050'); else await (await page.$('.opt')).click();
        await page.click('#xsave');
      }
      await page.click('#go'); continue;
    }
    const it = B.byId(sc.id);
    await page.waitForTimeout(p.rapid ? 5 : 40);
    if (it.readcheck) {
      const pass = p.readOk[rc++] === 1; const opts = await page.$$('.opt');
      await opts[pass ? it.answer : 0].click(); await page.click('#next'); continue;
    }
    if (it.type === 'steps') {
      const stepped = sc.cond === 'stepped'; const n = (stepped ? it.steps.length : 0) + 1;
      for (let k = 0; k < n; k++) {
        const q = (stepped ? it.steps : []).concat([it.final])[k], last = k === n - 1;
        if (p.rapid) { await page.click('#skip'); continue; }
        // trap students skip steps: pick the stop-early/skip-step distractor when unscaffolded
        let pick = q.options.findIndex(o => o.kind === 'correct');
        if (!stepped && p.trapSkips && last) { const d = q.options.findIndex(o => /stopEarly|skipStep/.test(o.kind)); if (d > -1) pick = d; }
        if (!p.knows('multistep')) pick = (pick + 1) % 4;
        await (await page.$$('.opt'))[pick].click(); await page.click('#next');
      }
      continue;
    }
    if (it.type === 'project') {
      for (let k = 0; k < it.parts.length; k++) {
        if (p.rapid || !p.knows('linear')) { await page.click('#skip'); continue; }
        await page.fill('#ans', it.parts[k].accept[0]); await page.click('#next');
      }
      continue;
    }
    // simple item
    const isMc = it.type === 'mc' || it.qtype === 'mc';
    const ownTag = (it.tags && it.tags[0]) || 'x';
    const knows = p.knows(ownTag) || (it.tags || []).some(t => p.knows(t));
    const answer = isMc ? it.answer : (it.type === 'expr' ? '123+4-5+67-89' : it.accept[0]);
    const wrong = isMc ? (it.answer + 1) % it.options.length : '999';
    // open-format starting behaviour
    const startsOpen = it.block !== 'B' || sc.cond !== 'open' ? true : p.startOpen;
    if (it.scaffold && sc.cond === 'forced') {
      if (!p.startForced) { await page.click('#skip'); continue; }
      const sfs = await page.$$('.sf'); for (let i = 0; i < sfs.length; i++) await sfs[i].fill(it.scaffold.fields[i].accept[0]);
      await page.click('#sfgo');
    }
    if (it.menu && sc.cond === 'choice') { await (await page.$('#menu button')).click(); }
    if (p.rapid) { await page.click('#skip'); continue; }
    if (it.block === 'C' && p.fear && ['credit'].includes(sc.cond)) { await page.click('#skip'); continue; }
    if (it.block === 'B' && sc.cond === 'open' && !startsOpen) { await page.click('#skip'); continue; }
    if (it.block === 'E' && !it.retry) { await page.click('#skip'); continue; }
    if (it.id === 'E4' || (it.retry && p.persist < 0.7 && it.level !== 'easy')) {
      // weak persistence: one wrong attempt then move on
      if (isMc) {} else { await page.fill('#ans', it.type === 'expr' ? '1+2+3+4+5+6+7+8+9' : '999'); await page.click('#next'); }
      if (p.persist >= 0.7 && it.id === 'E4') { await page.fill('#ans', '123+4-5+67-89'); await page.click('#next'); await page.click('#next'); continue; }
      await page.click('#skip'); continue;
    }
    if (it.id.startsWith('X')) { continue; }
    const kn = knows || it.block === 'A' && it.floor;
    if (isMc) {
      await (await page.$$('.opt'))[kn ? answer : wrong].click();
      if (it.why) await page.fill('#why', 'because');
    } else {
      await page.fill('#ans', String(kn ? answer : wrong));
    }
    if (it.confidence) await (await page.$$('#conf .opt'))[1].click();
    if (it.retry) {
      await page.click('#next'); // Check
      if (!(await page.$('#next:not([disabled])'))) {}
      const label = await page.textContent('#next');
      if (label.trim() === 'Continue') await page.click('#next'); else await page.click('#skip');
    } else await page.click('#next');
  }
  // try browser back: should be blocked and logged
  await page.goBack().catch(() => {});
  const res = await page.evaluate(() => { const S = window.__sd.S; return JSON.parse(JSON.stringify({ r: S })); });
  const result = await page.evaluate(() => { const S = window.__sd.S; return null; });
  // pull the downloadable result via the page's own builder through the download button
  const [dl] = await Promise.all([page.waitForEvent('download'), page.click('#dl')]);
  const path = `${OUT}/${key}.json`; await dl.saveAs(path);
  await ctx.close();
  return { path, errs, n: JSON.parse(fs.readFileSync(path, 'utf8')).records.length };
}

const only = process.argv[2];
const browser = await chromium.launch();
let bad = 0;
for (const [key, p] of Object.entries(profiles)) {
  if (only && only !== key) continue;
  const t = Date.now();
  const r = await run(browser, key, p);
  console.log(key.padEnd(11), 'records', r.n, 'errors', r.errs.length ? r.errs : 'none', (Date.now() - t) + 'ms');
  if (r.errs.length) bad++;
}
await browser.close();
process.exit(bad ? 1 : 0);
