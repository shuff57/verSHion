// Shared helpers for the browser tests: project paths and a Playwright loader that works from a normal checkout.
import { createRequire } from 'module';
import path from 'path';
import fs from 'fs';
import { fileURLToPath, pathToFileURL } from 'url';

export const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const outDir = process.env.TENSHION_OUT || path.join(root, 'tests', 'out');
fs.mkdirSync(outDir, { recursive: true });
export const fileUrl = (rel) => pathToFileURL(path.join(root, rel)).href;

export function loadPlaywright() {
  const places = [root + '/', process.env.PLAYWRIGHT_NODE_MODULES].filter(Boolean);
  for (const p of places) { try { return createRequire(p)('playwright'); } catch (e) { /* try next */ } }
  throw new Error('Playwright is not installed. Run:  npm install  &&  npx playwright install chromium');
}
