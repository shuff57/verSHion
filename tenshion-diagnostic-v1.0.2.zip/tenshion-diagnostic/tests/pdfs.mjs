import { createRequire } from 'module';
import { loadPlaywright, fileUrl, outDir, root } from './_env.mjs';
const { chromium } = loadPlaywright();
const out = outDir + '/';
const browser = await chromium.launch();
const page = await (await browser.newContext({ viewport: { width: 1000, height: 1200 } })).newPage();
const errs = []; page.on('pageerror', e => errs.push(String(e)));
const base = fileUrl('dist/site/print.html');
for (const [name, q] of [['formA', '?form=A'], ['formB', '?form=B'], ['key', '?form=A&key=1']]) {
  await page.goto(base + q); await page.waitForTimeout(150);
  await page.pdf({ path: `${root}/dist/site/booklet-${name}.pdf`, format: 'Letter', printBackground: true, preferCSSPageSize: true });
}
await page.goto(base + '?form=A'); await page.screenshot({ path: out + 'p-screen.png' });
console.log('errors', errs);
await browser.close();
