#!/usr/bin/env python3
"""Build tenSHion Diagnostic.

    python3 build.py

Reads src/ and site.json, writes:
  dist/site/      self-contained static site: index.html (landing), test.html, viewer.html, print.html
                  (plus booklet PDFs if you have generated them with `npm run pdfs`)
  dist/artifact/  the same pages with the document wrapper removed, for publishing as claude.ai artifacts
"""
import json, pathlib, re, sys
root = pathlib.Path(__file__).resolve().parent
src, dist = root / 'src', root / 'dist'
site_dir, art_dir = dist / 'site', dist / 'artifact'
for d in (site_dir, art_dir):
    d.mkdir(parents=True, exist_ok=True)
cfg = json.loads((root / 'site.json').read_text(encoding='utf-8'))

js = {n: (src / f'{n}.js').read_text(encoding='utf-8') for n in ('bank', 'analysis')}
theme = (src / 'theme.css').read_text(encoding='utf-8').strip()
defs = (src / 'defs.html').read_text(encoding='utf-8').strip()
sample = (src / 'sample-codes.json').read_text(encoding='utf-8') if (src / 'sample-codes.json').exists() else '[]'

def theme_it(html):
    """Insert the shared palette (src/theme.css) and the chalk filter (src/defs.html)."""
    return html.replace('/*THEME*/', theme).replace('<!--DEFS-->', defs)

def inline(html):
    html = theme_it(html)
    for tag, name in (('<!--BANK-->', 'bank'), ('<!--ANALYSIS-->', 'analysis')):
        if tag in html:
            html = html.replace(tag, '<script>\n' + js[name].replace('</script>', '<\\/script>') + '\n</script>')
    return html.replace('<!--SAMPLE-->', '<script>window.SAMPLE_CODES=' + sample + ';</script>')

def unwrap(html):
    """Remove the <!doctype>/<html>/<head>/<body> wrapper; the artifact publisher adds its own skeleton."""
    html = re.sub(r'^\s*<!doctype html>\s*', '', html, flags=re.I)
    html = re.sub(r'<html[^>]*>\s*<head>\s*', '', html, count=1)
    html = re.sub(r'<meta charset="utf-8">\s*', '', html, count=1)
    html = re.sub(r'<meta name="viewport"[^>]*>\s*', '', html, count=1)
    html = html.replace('</head>', '', 1)
    html = re.sub(r'<body[^>]*>', '', html, count=1)
    return html.replace('</body>', '').replace('</html>', '').strip() + '\n'

def wrap_landing(body):
    """The landing page is authored as bare content (title, styles, markup). Give it a document for static hosting."""
    head, sep, rest = body.partition('</style>')
    return ('<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n'
            '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n'
            + head + sep + '\n</head>\n<body>\n' + rest.strip() + '\n</body>\n</html>\n')

def landing(kind):
    html = theme_it((src / 'landing.html').read_text(encoding='utf-8'))
    c = cfg[kind]
    return (html.replace('__TEST_URL__', c['test']).replace('__VIEWER_URL__', c['viewer']).replace('__SHARE_NOTE__', c['shareNote']))

pages = {}
for page in ('test', 'viewer', 'print'):
    pages[page] = inline((src / f'{page}.html').read_text(encoding='utf-8'))
    (site_dir / f'{page}.html').write_text(pages[page], encoding='utf-8')
    print(f'built dist/site/{page}.html ({len(pages[page]) // 1024} KB)')

(site_dir / 'index.html').write_text(wrap_landing(landing('static')), encoding='utf-8')
print('built dist/site/index.html')

# artifact versions: landing + test + viewer (print stays a file: hosted pages cannot open a print dialog)
(art_dir / 'landing.html').write_text(landing('artifact'), encoding='utf-8')
for page in ('test', 'viewer'):
    (art_dir / f'{page}.html').write_text(unwrap(pages[page]), encoding='utf-8')
print('built dist/artifact/{landing,test,viewer}.html')
