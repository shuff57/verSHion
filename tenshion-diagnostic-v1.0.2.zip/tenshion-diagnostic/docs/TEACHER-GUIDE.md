# tenSHion Diagnostic: teacher guide

Use this to tell apart three reasons a student isn't working: **can't start** (needs an entry point or support), **chooses not to start**, or **doesn't have the prerequisite knowledge**. It also flags students who aren't reading or are rushing, because their results mean something different.

## Running it

1. Open `index.html` and use the link builder to make a student link: form, length, sitting, class label.
2. Send students the link. They enter a first name and class, read the rules, and begin.
3. Students can't go back. A refresh puts them on the same screen. Back attempts and reloads are logged.
4. At the end each student saves a results file or copies a results code, and hands it in however you collect work (Classroom, Canvas, a form, email).
5. Open `viewer.html`, drop the files in or paste the codes. Press "Try it with a sample class" first to see what it looks like.

Full length is about 60 minutes. The short version is about 25. For three shorter sittings use `blocks-ABC`, then `blocks-DGKH`, then `blocks-FEXS`. The viewer merges a student's sittings by name and class.

## What students are told

The welcome screen says you see their answers, their timing, and anything they type. Keep that line.

## Reading the viewer

Three tabs: **Students** (one row each with a pattern, the evidence, and a suggested next move), **Class comparisons** (paired results across conditions), **Items** (which wrong options students picked, which shows the step they skipped). The cord in the header has one bead per student, colored by pattern. Select a bead to open that student.

Patterns: starts and persists, can't start without support, chooses not to start, missing prerequisite knowledge, not reading or rushing, not enough data.

- Each label is a **hypothesis** with the signals behind it and how strong they are.
- One student sees only a few items per condition, so single-student comparisons are noisy. **Class-level comparisons are more reliable.**
- "Not reading or rushing" is checked first: three reading checks placed early, middle and late, plus the share of screens answered faster than reading speed. If a student fails these, treat their other results cautiously.
- Floor items (very basic prerequisites) separate "doesn't know" from "didn't try". A quick miss with no work reads as disengagement. A miss after effort reads as a knowledge gap.

## Keep the banners true

Form A and Form B put the same tasks under different banners (not graded, your teacher reads it, counts for participation points). If a banner says an item counts, it has to. Honor it, or change the wording in `src/bank.js` before you give the test.

## Paper version

Use the PDFs when devices are an issue. Paper can't enforce forward-only and has no per-screen timing, so you lose rapid-response and back-tracking data. The time-in and time-out boxes are a coarse substitute. Use `booklet-key.pdf` to score.

## Known limits

- The full test is long. Use sittings or the short version.
- Cutoffs, such as the rapid-response threshold, are reasoned defaults and have not been normed on real students. Treat early results as calibrating your own picture of your classes.
- It measures behavior in this setting. A student who stalls on a laptop may behave differently with you at the table.
- It has been tested with scripted students and a real browser, not yet piloted with a class. A first run with one class is the real check.
