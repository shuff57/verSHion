/* Scoring, per-student summaries, pattern classification, and class-level comparisons.
   Used by the results viewer and by the Node tests. Reads the result files the student test saves. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./bank.js'));
  else root.ANALYSIS = factory(root.BANK);
})(typeof self !== 'undefined' ? self : this, function (B) {
  'use strict';

  /* ---------- small helpers ---------- */
  function med(a) { a = a.filter(function (x) { return x !== null && x !== undefined && !isNaN(x); }).sort(function (x, y) { return x - y; }); if (!a.length) return null; var m = a.length >> 1; return a.length % 2 ? a[m] : (a[m - 1] + a[m]) / 2; }
  function mean(a) { a = a.filter(function (x) { return x !== null && x !== undefined && !isNaN(x); }); return a.length ? a.reduce(function (s, x) { return s + x; }, 0) / a.length : null; }
  function rate(list, fn) { if (!list.length) return null; return list.filter(fn).length / list.length; }
  function cnt(list, fn) { return list.filter(fn).length; }
  function sec(ms) { return ms === null || ms === undefined ? null : Math.round(ms / 100) / 10; }
  function pct(x) { return x === null || x === undefined ? '—' : Math.round(100 * x) + '%'; }
  function frac(n, d) { return n + ' of ' + d; }
  var SKIP_KINDS = /^(stopEarly|skipStep|skipAhead)$/;

  /* ---------- per-record judgments ---------- */
  function isRapid(r) {
    if (!r.thr) return false;
    var t = r.firstActionMs !== null && r.firstActionMs !== undefined ? r.firstActionMs : r.ms;
    if (r.choiceMs !== null && r.choiceMs !== undefined && r.firstActionMs !== null && r.firstActionMs !== undefined) t = Math.max(0, r.firstActionMs - r.choiceMs);
    return t < r.thr;
  }
  function engaged(r) {
    if (r.type === 'steps') return (r.steps || []).some(function (s) { return !s.skipped; });
    if (r.type === 'project') return (r.parts || []).some(function (p) { return !p.skipped; });
    if (r.type === 'open' || r.type === 'expr')
      return (r.notesChars || 0) >= 8 || (r.answer !== null && r.answer !== undefined) || (r.attempts || []).length > 0 ||
        !!(r.scaffold && r.scaffold.values && r.scaffold.values.some(function (v) { return v; }));
    return !r.skipped && r.answer !== null && r.answer !== undefined;
  }
  function startLatency(r) {
    if (r.firstActionMs === null || r.firstActionMs === undefined) return null;
    if (r.choiceMs !== null && r.choiceMs !== undefined) return Math.max(0, r.firstActionMs - r.choiceMs);
    return r.firstActionMs;
  }

  /* ---------- merging result files ---------- */
  function keyOf(res) { return String((res.student && res.student.name) || '').trim().toLowerCase() + '|' + String((res.student && res.student.code) || '').trim().toLowerCase(); }
  // Several files for the same name+class (separate sittings) become one student. A repeated item keeps its latest record.
  function merge(results) {
    var map = {}, order = [];
    results.slice().sort(function (a, b) { return String(a.startedAt).localeCompare(String(b.startedAt)); }).forEach(function (res) {
      if (!res || res.kind !== 'start-diagnostic') return;
      var k = keyOf(res);
      if (!map[k]) { map[k] = { key: k, name: res.student.name, code: res.student.code, form: res.form, len: res.len, files: 0, preview: false, records: {}, order: [], survey: null, reloads: 0, backAttempts: 0, device: res.device, sittings: [], bankSig: res.bankSig, versions: [], formMismatch: false }; order.push(k); }
      var s = map[k]; var ver = res.version || 'unversioned'; if (s.versions.indexOf(ver) < 0) s.versions.push(ver); s.files++; s.preview = s.preview || !!res.teacherMode;
      if (s.form !== res.form) s.formMismatch = true;
      s.reloads += res.reloads || 0; s.backAttempts += res.backAttempts || 0;
      s.sittings.push({ blocks: res.blocks || 'all', startedAt: res.startedAt, finishedAt: res.finishedAt, activeMs: res.activeMs });
      (res.records || []).forEach(function (r) {
        var id = r.id; if (r.kind === 'intro') id = 'intro-' + r.block;
        if (!(id in s.records)) s.order.push(id);
        s.records[id] = r;
      });
      if (res.survey) s.survey = res.survey;
    });
    return order.map(function (k) { return map[k]; });
  }

  /* ---------- per-student summary ---------- */
  function summarize(stu) {
    var recs = stu.order.map(function (id) { return stu.records[id]; });
    var items = recs.filter(function (r) { return r.kind === 'item'; });
    var by = function (block) { return items.filter(function (r) { return r.block === block; }); };
    var m = { name: stu.name, code: stu.code, form: stu.form, len: stu.len, preview: stu.preview, files: stu.files };

    // reading and rushing
    var rc = items.filter(function (r) { return r.block === 'R'; });
    var instr = stu.records.instructions;
    var scored = items.filter(function (r) { return ['A', 'C', 'G', 'H', 'K'].indexOf(r.block) > -1; });
    var scoredRapid = scored.filter(isRapid);
    m.read = { total: rc.length, passed: cnt(rc, function (r) { return r.passed; }), byPos: {}, instrMs: instr ? instr.ms : null, instrWords: instr ? instr.words : null,
      rapidN: scoredRapid.length, scoredN: scored.length, rapidRate: scored.length ? scoredRapid.length / scored.length : null };
    rc.forEach(function (r) { m.read.byPos[r.pos || r.id] = !!r.passed; });

    // floor + prerequisites
    var A = by('A'), FL = A.filter(function (r) { return /^FL/.test(r.id); }), PR = A.filter(function (r) { return !/^FL/.test(r.id); });
    m.floor = { total: FL.length, correct: cnt(FL, function (r) { return r.correct === true; }),
      missEffort: cnt(FL, function (r) { return r.correct !== true && !isRapid(r); }), rapidMiss: cnt(FL, function (r) { return r.correct !== true && isRapid(r); }) };
    var inf = PR.filter(function (r) { return r.correct === true || !isRapid(r); });
    m.know = { total: PR.length, correct: cnt(PR, function (r) { return r.correct === true; }), informative: inf.length,
      rate: inf.length ? cnt(inf, function (r) { return r.correct === true; }) / inf.length : null, tags: {}, weakTags: [] };
    var tagBuckets = {};
    PR.forEach(function (r) { (r.tags || []).forEach(function (t) { (tagBuckets[t] = tagBuckets[t] || []).push(r); }); });
    Object.keys(tagBuckets).forEach(function (t) {
      var l = tagBuckets[t].filter(function (r) { return r.correct === true || !isRapid(r); });
      m.know.tags[t] = l.length ? (cnt(l, function (r) { return r.correct === true; }) / l.length >= 0.5 ? 'ok' : 'gap') : 'unknown';
      if (m.know.tags[t] === 'gap') m.know.weakTags.push(t);
    });

    // initiation: math investigations, open vs forced
    var Bk = by('B'), bo = Bk.filter(function (r) { return r.cond === 'open'; }), bf = Bk.filter(function (r) { return r.cond === 'forced'; });
    m.init = { openN: bo.length, forcedN: bf.length, openRate: rate(bo, engaged), forcedRate: rate(bf, engaged), openCorrect: rate(bo, function (r) { return r.correct === true; }),
      forcedCorrect: rate(bf, function (r) { return r.correct === true; }), openLat: med(bo.map(startLatency)), forcedLat: med(bf.map(startLatency)),
      forcedFirstStepOk: bf.length ? rate(bf.filter(function (r) { return r.scaffold; }), function (r) { return r.scaffold.oks.every(Boolean); }) : null,
      hintsUsed: cnt(Bk, function (r) { return (r.hints || []).length > 0; }) };

    // other subjects vs math open-format
    var Dk = by('D'), Fk = by('F');
    var mathOpen = bo.concat(Dk);
    m.domain = { mathN: mathOpen.length, mathRate: rate(mathOpen, engaged), otherN: Fk.length, otherRate: rate(Fk, engaged),
      byDomain: {} };
    Fk.forEach(function (r) { m.domain.byDomain[r.domain] = { engaged: engaged(r), correct: r.correct === true, lat: startLatency(r) }; });

    // stakes
    var Ck = by('C'), ans = function (r) { return !r.skipped && r.answer !== null && r.answer !== undefined; };
    var low = Ck.filter(function (r) { return r.cond === 'low'; }), tea = Ck.filter(function (r) { return r.cond === 'teacher'; }), cr = Ck.filter(function (r) { return r.cond === 'credit'; });
    var hi = tea.concat(cr);
    function sk(l) { return { n: l.length, answered: rate(l, ans), correct: rate(l, function (r) { return r.correct === true; }), lat: med(l.map(startLatency)), conf: mean(l.filter(ans).map(function (r) { return r.conf; })) }; }
    m.stakes = { low: sk(low), teacher: sk(tea), credit: sk(cr), hi: sk(hi),
      underconf: cnt(Ck, function (r) { return r.correct === true && r.conf === 0; }), overconf: cnt(Ck, function (r) { return r.correct === false && r.conf === 2; }) };

    // choice
    var ch = Dk.filter(function (r) { return r.cond === 'choice'; }), as = Dk.filter(function (r) { return r.cond === 'assigned'; });
    function ck(l) { return { n: l.length, engaged: rate(l, engaged), lat: med(l.map(startLatency)), correct: rate(l, function (r) { return r.correct === true; }), choiceMs: med(l.map(function (r) { return r.choiceMs; })) }; }
    m.choice = { choice: ck(ch), assigned: ck(as), picked: ch.map(function (r) { return r.choice; }).filter(Boolean) };

    // multi-step
    var G = by('G'), trap = G.filter(function (r) { return r.cond === 'trap'; }), stp = G.filter(function (r) { return r.cond === 'stepped'; });
    m.steps = { trapN: trap.length, steppedN: stp.length, trapCorrect: rate(trap, function (r) { return r.correct === true; }), steppedCorrect: rate(stp, function (r) { return r.correct === true; }),
      trapSkipPicks: cnt(trap, function (r) { return SKIP_KINDS.test(r.pick || ''); }), trapPicks: {}, steppedFirstError: [], stepsRight: 0, stepsTotal: 0 };
    G.forEach(function (r) { if (r.cond === 'trap' && r.pick) m.steps.trapPicks[r.pick] = (m.steps.trapPicks[r.pick] || 0) + 1; });
    stp.forEach(function (r) {
      var fe = (r.steps || []).filter(function (s) { return s.correct === false || s.skipped; })[0];
      m.steps.steppedFirstError.push(fe ? fe.k : null);
      (r.steps || []).forEach(function (s) { m.steps.stepsTotal++; if (s.correct) m.steps.stepsRight++; });
    });

    // project
    var K = by('K')[0];
    m.project = null;
    if (K) {
      var pv = {}; (K.parts || []).forEach(function (p) { pv[p.key] = p; });
      var num = function (p) { return p && p.answer !== null && p.answer !== undefined ? B.toNumber(p.answer) : NaN; };
      var a = num(pv.a), b = num(pv.b), c = num(pv.c);
      var chain = !isNaN(a) && !isNaN(b) && !isNaN(c) ? (c === b - a) : null;
      var attempted = (K.parts || []).filter(function (p) { return !p.skipped; }).length;
      var lastAttempt = 0; (K.parts || []).forEach(function (p, i) { if (!p.skipped) lastAttempt = i + 1; });
      m.project = { right: K.partsCorrect || 0, total: (K.parts || []).length, attempted: attempted, lastAttempt: lastAttempt, chainConsistent: chain,
        wrongButConsistent: chain === true && !(pv.a && pv.a.correct && pv.b && pv.b.correct && pv.c && pv.c.correct),
        parts: (K.parts || []).map(function (p) { return { key: p.key, correct: p.correct, skipped: p.skipped, hint: p.hint }; }) };
    }

    // reasoning
    var H = by('H');
    m.reason = { total: H.length, correct: cnt(H, function (r) { return r.correct === true; }), picks: {}, whyN: cnt(H, function (r) { return (r.whyChars || 0) >= 10; }),
      byTag: {} };
    H.forEach(function (r) { if (r.pick && r.pick !== 'correct') m.reason.picks[r.pick] = (m.reason.picks[r.pick] || 0) + 1; var t = (r.tags || [])[0] || 'reasoning';
      var b2 = m.reason.byTag[t] = m.reason.byTag[t] || { n: 0, right: 0 }; b2.n++; if (r.correct) b2.right++; });

    // persistence
    var E = by('E'), E123 = E.filter(function (r) { return r.id !== 'E4'; }), E4 = E.filter(function (r) { return r.id === 'E4'; })[0];
    var per = { solvedFirst: 0, solvedRetry: 0, quitAfterError: 0, quitNoAttempt: 0, stuckBtn: 0, items: E123.length };
    E123.forEach(function (r) {
      var att = r.attempts || [], wrong = att.filter(function (x) { return !x.ok; }).length;
      if (r.correct && wrong === 0) per.solvedFirst++; else if (r.correct) per.solvedRetry++; else if (att.length === 0) per.quitNoAttempt++; else per.quitAfterError++;
      if ((r.hints || []).length) per.stuckBtn++;
    });
    per.quits = per.quitAfterError + per.quitNoAttempt;
    per.e4 = E4 ? { solved: !!E4.correct, attempts: (E4.attempts || []).length, valid: (E4.attempts || []).filter(function (x) { return !x.invalid; }).length, ms: E4.ms, hints: (E4.hints || []).length,
      best: (E4.attempts || []).filter(function (x) { return x.value !== undefined && x.value !== null; }).reduce(function (bst, x) { return Math.min(bst, Math.abs(x.value - 100)); }, Infinity), gaveUp: !!E4.gaveUp } : null;
    if (per.e4 && !isFinite(per.e4.best)) per.e4.best = null;
    m.persist = per;

    // self-starting
    var X = recs.filter(function (r) { return r.kind === 'extras'; })[0];
    m.self = X ? { total: X.extras.length, opened: cnt(X.extras, function (e) { return e.opened; }), answered: cnt(X.extras, function (e) { return e.opened && !e.skipped && !e.abandoned; }) } : null;

    m.survey = stu.survey;
    m.flags = {
      pastes: cnt(items, function (r) { return (r.pastedChars || 0) > 0; }), pastedChars: items.reduce(function (s, r) { return s + (r.pastedChars || 0); }, 0),
      hiddenSec: Math.round(items.reduce(function (s, r) { return s + (r.hiddenMs || 0); }, 0) / 1000), blurs: items.reduce(function (s, r) { return s + (r.blurs || 0); }, 0),
      back: stu.backAttempts, reloads: stu.reloads
    };
    m.coverage = { items: items.length, blocks: Object.keys(items.reduce(function (o, r) { o[r.block] = 1; return o; }, {})).sort().join(''), survey: !!stu.survey };
    m.totalMs = recs.reduce(function (s, r) { return s + (r.ms || 0); }, 0);
    m.itemsList = items;
    // overall engagement over open-format work
    var openFormat = bo.concat(bf, Dk, Fk, E);
    m.engageAll = openFormat.length ? rate(openFormat, engaged) : null;
    m.engageN = openFormat.length;
    return m;
  }

  /* ---------- classification ---------- */
  var BUCKETS = {
    knowledge: 'Missing prerequisite knowledge',
    unable: 'Can’t start without support',
    choose: 'Chooses not to start',
    unreliable: 'Not reading or rushing',
    ok: 'Starts and persists',
    unclear: 'Not enough data'
  };
  var NEXT = {
    knowledge: 'Sit with the student for five minutes on the weak topics listed and ask them to talk through one problem. Close that gap first. Starting is not the problem yet.',
    entry: 'Hand over a tiny required first step before the open question (“fill in row 4 and row 5”). Fading the step out over a few weeks tests whether the habit transfers.',
    steps: 'Give step labels and ask for each intermediate result in writing. The student can do the work but takes the shortcut when the steps are not named.',
    fear: 'Make first attempts low-visibility (private whiteboard, “guess, then check”) and grade process, not first answers. Ask them directly what happens when they are wrong in front of others.',
    value: 'Have a short conversation about what would make the work worth starting. Offer a choice of context, as this test did, and check their survey comments.',
    disengaged: 'Talk to the student first. The data shows no start even with the first step handed over, and a test cannot say why. Look at their survey comments for a reason.',
    persist: 'They start fine but stop at the first wrong answer. Practice a “wrong answer, then what?” routine: say one thing you learned from the miss before moving on.',
    unreliable: 'Retake in a supervised sitting with a short check-in first. These results are not interpretable.',
    ok: 'No concern from this screener. If class behavior says otherwise, look at the situation rather than the student.'
  };

  function likert(m, id) { return m.survey && m.survey.likert ? m.survey.likert[id] : null; }
  function why(m, key) { return !!(m.survey && m.survey.why && m.survey.why.indexOf(key) > -1); }

  function classify(m, cfg) {
    var cutoff = ((cfg || B.CONFIG).knowledgeCutoff || 6) / 9;
    var sig = [], notes = [];
    function push(id, strength, bucket, label, evidence) { sig.push({ id: id, strength: strength, bucket: bucket, label: label, evidence: evidence }); }
    var S = { strong: 3, moderate: 2, weak: 1 };

    // 1. reading and rushing
    var rd = m.read, rrate = rd.rapidRate;
    if (rd.total >= 2 && rd.total - rd.passed >= 2) push('reading', 'strong', 'unreliable', 'Missed reading checks', 'Passed ' + frac(rd.passed, rd.total) + ' reading checks.');
    else if (rd.total >= 1 && rd.passed === 0) push('reading', 'strong', 'unreliable', 'Missed reading checks', 'Passed 0 of ' + rd.total + ' reading checks.');
    else if (rd.total - rd.passed === 1) notes.push('Missed one reading check (' + Object.keys(rd.byPos).filter(function (k) { return !rd.byPos[k]; })[0] + ' in the sitting). One miss alone is not conclusive.');
    if (rrate !== null && rd.scoredN >= 8) {
      if (rrate >= 0.5) push('rapid', 'strong', 'unreliable', 'Mostly rapid responses', rd.rapidN + ' of ' + rd.scoredN + ' scored screens were answered faster than a person can read them.');
      else if (rrate >= 0.3) push('rapid', 'moderate', 'unreliable', 'Many rapid responses', rd.rapidN + ' of ' + rd.scoredN + ' scored screens were answered faster than a person can read them.');
    }
    if (rd.instrMs !== null && rd.instrWords && rd.instrMs < rd.instrWords * 80) notes.push('Spent ' + sec(rd.instrMs) + ' s on the instructions screen (about ' + rd.instrWords + ' words).');

    // 2. floor + prerequisites
    var fl = m.floor;
    if (fl.total >= 2 && fl.missEffort >= 2) push('floor', 'strong', 'knowledge', 'Below the floor', 'Missed ' + fl.missEffort + ' of ' + fl.total + ' very easy items while working on them (not rushing).');
    else if (fl.missEffort === 1) notes.push('Missed one floor item with real effort.');
    if (fl.rapidMiss >= 1) notes.push(fl.rapidMiss + ' floor item(s) missed or skipped in under a few seconds. That looks like effort, not knowledge.');
    var kn = m.know;
    if (kn.informative >= 4 && kn.rate !== null && kn.rate < cutoff)
      push('know', kn.rate < cutoff - 0.2 ? 'strong' : 'moderate', 'knowledge', 'Prerequisite gap',
        'Got ' + kn.correct + ' of ' + kn.total + ' prerequisite items right' + (kn.weakTags.length ? '. Weak areas: ' + kn.weakTags.join(', ') : '') + '.');
    var knowledgeStrong = sig.some(function (s) { return s.bucket === 'knowledge' && s.strength === 'strong'; });

    // 3. initiation
    var ini = m.init;
    if (ini.openN >= 1 && ini.forcedN >= 1) {
      if (ini.openRate < ini.forcedRate && ini.openRate <= 0.5)
        push('entry', ini.openRate === 0 && ini.forcedRate === 1 ? 'strong' : 'moderate', 'unable', 'Needs an entry point',
          'Started ' + frac(Math.round(ini.openRate * ini.openN), ini.openN) + ' open investigations, but ' + frac(Math.round(ini.forcedRate * ini.forcedN), ini.forcedN) + ' when the first step was handed over.');
      else if (ini.forcedRate === 0) push('forcedStall', 'moderate', 'choose', 'No start even with the first step given', 'Did not begin either investigation, including the one with a tiny first step handed over.');
      else if (ini.openRate >= 0.5 && ini.forcedRate >= 0.5) notes.push('Starts open investigations on their own (' + frac(Math.round(ini.openRate * ini.openN), ini.openN) + ').');
    }

    // 4. skipped steps
    var st = m.steps;
    if (st.trapN >= 1 && st.steppedN >= 1 && st.steppedCorrect > st.trapCorrect && st.trapSkipPicks >= 1)
      push('steps', st.trapCorrect === 0 && st.steppedCorrect === 1 ? 'strong' : 'moderate', 'unable', 'Skips steps without structure',
        'Chose a skipped-step answer on ' + frac(st.trapSkipPicks, st.trapN) + ' answer-only problems, but got ' + frac(Math.round(st.steppedCorrect * st.steppedN), st.steppedN) + ' right when the steps were laid out.');
    else if (st.trapN >= 1 && st.steppedN >= 1 && st.steppedCorrect !== null && st.steppedCorrect < 1 && st.stepsTotal && st.stepsRight / st.stepsTotal < 0.7)
      notes.push('Missed several individual steps even when guided (' + frac(st.stepsRight, st.stepsTotal) + ' steps right). That points to procedure, not step-skipping.');

    // 5. fear of error
    var sk = m.stakes, a = false, b = false, c = false, ev = [];
    if (sk.low.n >= 1 && sk.hi.n >= 1) {
      var skipLow = 1 - (sk.low.answered === null ? 1 : sk.low.answered), skipHi = 1 - (sk.hi.answered === null ? 1 : sk.hi.answered);
      if (skipHi - skipLow >= 0.5) { a = true; ev.push('Answered ' + pct(sk.low.answered) + ' of the no-stakes problems but ' + pct(sk.hi.answered) + ' when your teacher would read it or it counted.'); }
      else if (sk.low.correct !== null && sk.hi.correct !== null && sk.low.correct - sk.hi.correct >= 0.5) { a = true; ev.push('Correct on ' + pct(sk.low.correct) + ' of no-stakes problems versus ' + pct(sk.hi.correct) + ' under higher stakes.'); }
    }
    var s2 = likert(m, 'S2'), s7 = likert(m, 'S7');
    if ((s2 !== null && s2 >= 4) || (s7 !== null && s7 >= 4) || why(m, 'fear')) { b = true; ev.push('Survey: says they avoid risking a wrong answer or feel nervous being watched.'); }
    if (sk.underconf >= 2) { c = true; ev.push('Rated themselves “guessing” on ' + sk.underconf + ' answers that were correct.'); }
    if (a && b) push('fear', 'strong', 'unable', 'Fear of being wrong', ev.join(' '));
    else if (a || (b && c)) push('fear', 'moderate', 'unable', 'Possible fear of being wrong', ev.join(' '));
    else if (b || c) notes.push(ev.join(' '));

    // 6. value / motivation
    var chc = m.choice, vEv = [], vA = false, vB = false;
    if (chc.choice.n >= 1 && chc.assigned.n >= 1 && chc.choice.engaged !== null && chc.assigned.engaged !== null && chc.choice.engaged > chc.assigned.engaged) { vA = true; vEv.push('Engaged with ' + pct(chc.choice.engaged) + ' of the choose-your-context problems versus ' + pct(chc.assigned.engaged) + ' of the assigned ones.'); }
    else if (chc.choice.lat !== null && chc.assigned.lat !== null && chc.assigned.lat > 2 * chc.choice.lat && chc.assigned.lat - chc.choice.lat > 8000)
      notes.push('Started in ' + sec(chc.choice.lat) + ' s when they picked the context versus ' + sec(chc.assigned.lat) + ' s when it was assigned. One comparison is noisy, so this is a hint only.');
    var s6 = likert(m, 'S6'), s4 = likert(m, 'S4');
    if ((s6 !== null && s6 >= 4) || why(m, 'value')) { vB = true; vEv.push('Survey: says the work feels pointless or boring.'); }
    if (vA && vB) push('value', 'strong', 'choose', 'Relevance and choice matter', vEv.join(' '));
    else if (vA || vB) push('value', 'moderate', 'choose', 'Possible motivation issue', vEv.join(' '));
    else if (s4 !== null && s4 >= 4) notes.push('Survey: says they start more easily when they can pick the situation.');

    // 7. overall disengagement
    if (m.engageAll !== null && m.engageN >= 4 && m.engageAll < 0.4 && !knowledgeStrong)
      push('disengaged', why(m, 'value') || why(m, 'state') ? 'strong' : 'moderate', 'choose', 'Low engagement across tasks',
        'Engaged with ' + pct(m.engageAll) + ' of the open-format tasks (' + m.engageN + ' tasks).' + (why(m, 'state') ? ' Survey: tired or distracted.' : ''));

    // 8. persistence
    var pe = m.persist;
    if (pe.items + (pe.e4 ? 1 : 0) >= 2 && (m.engageAll === null || m.engageAll >= 0.6)) {
      var q = pe.quits + (pe.e4 && !pe.e4.solved && pe.e4.attempts <= 1 && pe.e4.ms < 45000 ? 1 : 0);
      if (q >= 2) push('persist', 'moderate', 'unable', 'Stops at the first wrong answer', 'Stopped after one wrong try (or none) on ' + q + ' of the harder problems, even though they start tasks readily.');
    }

    // choose primary
    var PRI = ['reading', 'rapid', 'floor', 'know', 'entry', 'steps', 'fear', 'persist', 'value', 'forcedStall', 'disengaged'];
    var strong = sig.filter(function (s) { return s.strength !== 'weak'; });
    strong.sort(function (x, y) { return PRI.indexOf(x.id) - PRI.indexOf(y.id); });
    var primary = strong[0] || null, bucket, next, label, conf;
    var enough = m.coverage.items >= 8;
    if (primary) {
      bucket = primary.bucket; label = primary.label; conf = primary.strength === 'strong' ? 'strong' : 'tentative';
      next = { reading: NEXT.unreliable, rapid: NEXT.unreliable, floor: NEXT.knowledge, know: NEXT.knowledge, entry: NEXT.entry, steps: NEXT.steps, fear: NEXT.fear, persist: NEXT.persist, value: NEXT.value, forcedStall: NEXT.disengaged, disengaged: NEXT.disengaged }[primary.id];
    } else if (!enough) { bucket = 'unclear'; label = BUCKETS.unclear; conf = 'insufficient'; next = 'Fewer than 8 items were completed. Run more of the test before reading anything into this.'; }
    else { bucket = 'ok'; label = BUCKETS.ok; conf = m.engageN >= 4 ? 'strong' : 'tentative'; next = NEXT.ok; }

    // context notes
    var d = m.domain;
    if (d.mathN >= 2 && d.otherN >= 2 && d.mathRate !== null && d.otherRate !== null) {
      if (d.otherRate - d.mathRate >= 0.5) notes.push('Starts readily in science, code, reading and spatial tasks (' + pct(d.otherRate) + ') but not in math (' + pct(d.mathRate) + '). The avoidance looks math-specific.');
      else if (d.otherRate < 0.5 && d.mathRate < 0.5) notes.push('Low start rate in math (' + pct(d.mathRate) + ') and in other subjects (' + pct(d.otherRate) + '). It does not look math-specific.');
    }
    if (m.reason.total >= 3 && m.reason.correct / m.reason.total >= 0.67) notes.push('Reasoning is a strength: ' + frac(m.reason.correct, m.reason.total) + ' reasoning items right' + (kn.weakTags.length ? ', despite gaps in ' + kn.weakTags.join(', ') + '.' : '.'));
    var fp = m.reason.picks;
    if (fp.affirmConsequent) notes.push('Chose the classic “flip the number that confirms the rule” answer on the card problem (a common reasoning slip).');
    if (m.project) {
      if (m.project.wrongButConsistent) notes.push('On the longer problem, their later answers follow from their own earlier ones even where an arithmetic slip crept in. The method is sound.');
      if (m.project.attempted < m.project.total && m.project.attempted > 0) notes.push('Longer problem: stopped after part ' + m.project.lastAttempt + ' of ' + m.project.total + '.');
    }
    if (m.self && m.self.total) notes.push('Optional extras: opened ' + frac(m.self.opened, m.self.total) + '.');
    if (m.flags.pastes >= 2) notes.push('Pasted text on ' + m.flags.pastes + ' screens.');
    if (m.flags.hiddenSec >= 90) notes.push('Left the test tab for about ' + Math.round(m.flags.hiddenSec / 60 * 10) / 10 + ' minutes in total.');
    if (m.flags.back > 0) notes.push('Tried to go back ' + m.flags.back + ' time(s).');
    if (!enough && bucket !== 'unclear') notes.push('Only ' + m.coverage.items + ' items completed. Treat this as a first impression.');

    return { bucket: bucket, bucketLabel: BUCKETS[bucket], label: label, confidence: conf, primary: primary, signals: sig.sort(function (x, y) { return PRI.indexOf(x.id) - PRI.indexOf(y.id); }), notes: notes, next: next };
  }

  /* ---------- class level ---------- */
  function classSummary(sums) {
    var live = sums.filter(function (s) { return !s.m.preview; }), out = { n: live.length, buckets: {}, comparisons: {}, tags: {}, items: [], reading: {} };
    live.forEach(function (s) { out.buckets[s.c.bucket] = (out.buckets[s.c.bucket] || 0) + 1; });
    var M = live.map(function (s) { return s.m; });
    function pair(list, getA, getB) {
      var both = list.filter(function (m) { return getA(m) !== null && getB(m) !== null; });
      if (!both.length) return null;
      return { n: both.length, a: mean(both.map(getA)), b: mean(both.map(getB)), aOnly: cnt(both, function (m) { return getA(m) > getB(m); }), bOnly: cnt(both, function (m) { return getB(m) > getA(m); }), same: cnt(both, function (m) { return getA(m) === getB(m); }) };
    }
    out.comparisons.start = pair(M, function (m) { return m.init.openRate; }, function (m) { return m.init.forcedRate; });
    out.comparisons.startLat = { open: med(M.map(function (m) { return m.init.openLat; })), forced: med(M.map(function (m) { return m.init.forcedLat; })) };
    out.comparisons.stakes = {
      low: { answered: mean(M.map(function (m) { return m.stakes.low.answered; })), correct: mean(M.map(function (m) { return m.stakes.low.correct; })), lat: med(M.map(function (m) { return m.stakes.low.lat; })) },
      teacher: { answered: mean(M.map(function (m) { return m.stakes.teacher.answered; })), correct: mean(M.map(function (m) { return m.stakes.teacher.correct; })), lat: med(M.map(function (m) { return m.stakes.teacher.lat; })) },
      credit: { answered: mean(M.map(function (m) { return m.stakes.credit.answered; })), correct: mean(M.map(function (m) { return m.stakes.credit.correct; })), lat: med(M.map(function (m) { return m.stakes.credit.lat; })) }
    };
    out.comparisons.choice = pair(M, function (m) { return m.choice.choice.engaged; }, function (m) { return m.choice.assigned.engaged; });
    out.comparisons.choiceLat = { choice: med(M.map(function (m) { return m.choice.choice.lat; })), assigned: med(M.map(function (m) { return m.choice.assigned.lat; })) };
    out.comparisons.steps = pair(M, function (m) { return m.steps.trapCorrect; }, function (m) { return m.steps.steppedCorrect; });
    out.comparisons.domain = pair(M, function (m) { return m.domain.mathRate; }, function (m) { return m.domain.otherRate; });
    ['early', 'middle', 'late'].forEach(function (p) {
      var l = M.filter(function (m) { return p in m.read.byPos; }); out.reading[p] = l.length ? { n: l.length, pass: cnt(l, function (m) { return m.read.byPos[p]; }) / l.length } : null;
    });
    var tagSet = {}; M.forEach(function (m) { Object.keys(m.know.tags).forEach(function (t) { tagSet[t] = 1; }); });
    Object.keys(tagSet).forEach(function (t) {
      var l = M.filter(function (m) { return m.know.tags[t] && m.know.tags[t] !== 'unknown'; });
      out.tags[t] = { n: l.length, ok: l.length ? cnt(l, function (m) { return m.know.tags[t] === 'ok'; }) / l.length : null };
    });
    // item table
    var ids = {}, order = [];
    live.forEach(function (s) { s.m.itemsList.forEach(function (r) { if (!ids[r.id]) { ids[r.id] = []; order.push(r.id); } ids[r.id].push(r); }); });
    var seqIds = B.sequence('A', 'full').filter(function (x) { return x.kind === 'item'; }).map(function (x) { return x.id; });
    order.sort(function (x, y) { var i = seqIds.indexOf(x), j = seqIds.indexOf(y); return (i < 0 ? 999 : i) - (j < 0 ? 999 : j); });
    order.forEach(function (id) {
      var l = ids[id], it = B.byId(id), picks = {};
      l.forEach(function (r) { if (r.pick) picks[r.pick] = (picks[r.pick] || 0) + 1; });
      out.items.push({ id: id, block: it ? it.block : '', n: l.length, correct: rate(l, function (r) { return r.correct === true; }), skipped: rate(l, function (r) { return r.skipped; }),
        rapid: rate(l, isRapid), lat: med(l.map(startLatency)), engaged: rate(l, engaged), picks: picks, domain: it ? it.domain : '' });
    });
    return out;
  }

  /* ---------- input decoding (files or pasted codes) ---------- */
  function b64urlToBytes(s) { s = s.replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '='; var bin = atob(s), a = new Uint8Array(bin.length); for (var i = 0; i < bin.length; i++) a[i] = bin.charCodeAt(i); return a; }
  function decodeCode(str) {
    str = String(str).trim();
    var kind = str.slice(0, 4), body = str.slice(4);
    if (kind === 'SD0.') return Promise.resolve(JSON.parse(new TextDecoder().decode(b64urlToBytes(body))));
    if (kind !== 'SD1.') return Promise.reject(new Error('Not a results code'));
    var ds = new DecompressionStream('gzip'), w = ds.writable.getWriter(); w.write(b64urlToBytes(body)); w.close();
    return new Response(ds.readable).arrayBuffer().then(function (b) { return JSON.parse(new TextDecoder().decode(b)); });
  }

  /* ---------- csv ---------- */
  function csvCell(v) { if (v === null || v === undefined) return ''; v = String(v); return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; }
  function toCsv(rows) { return rows.map(function (r) { return r.map(csvCell).join(','); }).join('\n'); }
  function studentsCsv(sums) {
    var head = ['name', 'class', 'form', 'pattern', 'confidence', 'label', 'items_done', 'reading_passed', 'reading_total', 'rapid_rate', 'floor_correct', 'floor_total', 'prereq_correct', 'prereq_total',
      'open_start_rate', 'forced_start_rate', 'trap_correct', 'stepped_correct', 'reasoning_correct', 'reasoning_total', 'project_right', 'stakes_low_answered', 'stakes_hi_answered', 'choice_engaged', 'assigned_engaged', 'extras_opened', 'minutes'];
    var rows = [head];
    sums.forEach(function (s) {
      var m = s.m, c = s.c;
      rows.push([m.name, m.code, m.form, c.bucketLabel, c.confidence, c.label, m.coverage.items, m.read.passed, m.read.total, m.read.rapidRate === null ? '' : m.read.rapidRate.toFixed(2),
        m.floor.correct, m.floor.total, m.know.correct, m.know.total, m.init.openRate, m.init.forcedRate, m.steps.trapCorrect, m.steps.steppedCorrect, m.reason.correct, m.reason.total,
        m.project ? m.project.right : '', m.stakes.low.answered, m.stakes.hi.answered, m.choice.choice.engaged, m.choice.assigned.engaged, m.self ? m.self.opened : '', Math.round(m.totalMs / 6000) / 10]);
    });
    return toCsv(rows);
  }
  function itemsCsv(sums) {
    var rows = [['name', 'class', 'form', 'id', 'block', 'condition', 'correct', 'skipped', 'engaged', 'rapid', 'seconds_to_first_action', 'seconds_on_screen', 'attempts', 'hints', 'confidence', 'pick', 'notes']];
    sums.forEach(function (s) { s.m.itemsList.forEach(function (r) {
      rows.push([s.m.name, s.m.code, s.m.form, r.id, r.block, r.cond, r.correct, r.skipped, engaged(r), isRapid(r), sec(startLatency(r)), sec(r.ms), (r.attempts || []).length, (r.hints || []).length, r.conf, r.pick, r.notes || '']);
    }); });
    return toCsv(rows);
  }

  return { merge: merge, summarize: summarize, classify: classify, classSummary: classSummary, decodeCode: decodeCode, studentsCsv: studentsCsv, itemsCsv: itemsCsv,
    engaged: engaged, isRapid: isRapid, startLatency: startLatency, BUCKETS: BUCKETS, med: med, mean: mean, pct: pct, sec: sec };
});
