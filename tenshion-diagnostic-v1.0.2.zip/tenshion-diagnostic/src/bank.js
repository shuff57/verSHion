/* Item bank, answer checking, and sequence builder.
   Shared by the student test, the print booklet, and the results viewer.
   Edit this file to change wording, numbers, or banners, then run build.py. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.BANK = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  /* ---------- Settings you may want to change ---------- */
  var CONFIG = {
    product: 'tenSHion Diagnostic',
    // Semantic version. Bump MAJOR when scoring or item meaning changes (old and new data should not be pooled),
    // MINOR when items or screens are added, PATCH for wording and layout fixes. Add a line to CHANGELOG in the landing page.
    version: '1.0.2',
    released: '2026-10-20',
    testId: 'start-diagnostic-v1',
    title: 'How you get started',
    // These three banners are the "stakes" manipulation. Only keep wording you will honor.
    stakes: {
      low: 'Best guess is fine here. This one is not graded, and a wrong answer or a blank costs you nothing.',
      teacher: 'Your teacher will read your answer to this one. It is not graded.',
      credit: 'This one counts toward your participation points.'
    },
    // Optional: a URL that accepts a JSON POST (Apps Script, Cloudflare Worker). Leave '' to use file download only.
    submitUrl: '',
    // A response faster than rapidBaseMs + rapidPerWordMs * (words on screen) is flagged as a rapid response.
    rapidBaseMs: 1500,
    rapidPerWordMs: 150,
    // Prerequisite score (out of 9) below which a student is read as "knowledge gap".
    knowledgeCutoff: 6,
    // Shown on the "Before you start" screen. Edit freely; keep them true.
    instructions: [
      'This is not a grade. It shows your teacher how you get started on problems, which helps more than a score. The questions marked “counts toward participation” do count.',
      'You can’t go back. Once you press Next, that screen is finished.',
      '“I don’t know” and “Skip” are real answers. Use them when they are true.',
      'Scratch paper and a basic calculator are fine. Please don’t open other tabs or apps, and don’t ask other people or AI tools for help.',
      'The test records how long each screen takes, what you type, and when you press “I’m stuck.” Your teacher can see all of it.',
      'A few screens check that you are reading closely. They are not graded.'
    ],
    submitHelp: 'Upload the file where your teacher told you to, for example as a Canvas assignment.'
  };

  /* ---------- Small helpers ---------- */
  function frac(n, d) { return '<span class="frac"><sup>' + n + '</sup>&frasl;<sub>' + d + '</sub></span>'; }

  function barChart(labels, values, yMax, step) {
    var W = 380, H = 230, L = 40, B = 46, T = 14, R = 10;
    var pw = W - L - R, ph = H - T - B, n = values.length, slot = pw / n, bw = slot * 0.58;
    var s = '<svg class="chart" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Bar chart">';
    for (var v = 0; v <= yMax; v += step) {
      var y = T + ph - (v / yMax) * ph;
      s += '<line x1="' + L + '" x2="' + (W - R) + '" y1="' + y + '" y2="' + y + '" stroke="currentColor" stroke-opacity="' + (v === 0 ? 0.9 : 0.18) + '"/>';
      s += '<text x="' + (L - 6) + '" y="' + (y + 4) + '" text-anchor="end" font-size="11" fill="currentColor">' + v + '</text>';
    }
    for (var i = 0; i < n; i++) {
      var bh = (values[i] / yMax) * ph, x = L + i * slot + (slot - bw) / 2;
      s += '<rect x="' + x + '" y="' + (T + ph - bh) + '" width="' + bw + '" height="' + bh + '" fill="currentColor" fill-opacity="0.55"/>';
      s += '<text x="' + (x + bw / 2) + '" y="' + (H - B + 18) + '" text-anchor="middle" font-size="12" fill="currentColor">' + labels[i] + '</text>';
    }
    return s + '</svg>';
  }

  function table(head, rows) {
    var h = '<table class="data"><thead><tr>' + head.map(function (c) { return '<th>' + c + '</th>'; }).join('') + '</tr></thead><tbody>';
    rows.forEach(function (r) { h += '<tr>' + r.map(function (c) { return '<td>' + c + '</td>'; }).join('') + '</tr>'; });
    return h + '</tbody></table>';
  }

  function dealText(ctx, fixed, perA, perB) {
    var C = {
      sports: { intro: 'Two ways to pay for the climbing gym.', a: 'Pass A', b: 'Pass B', join: 'to join', unit: 'visit', q: 'visits' },
      games:  { intro: 'Two ways to pay for an online game.', a: 'Plan A', b: 'Plan B', join: 'up front', unit: 'match', q: 'matches' },
      music:  { intro: 'Two ways to rent a practice room.', a: 'Option A', b: 'Option B', join: 'deposit', unit: 'session', q: 'sessions' },
      build:  { intro: 'Two ways to rent a power tool.', a: 'Rental A', b: 'Rental B', join: 'deposit', unit: 'day', q: 'days' },
      bus:    { intro: 'Two ways to pay for the city bus.', a: 'Pass A', b: 'Pass B', join: 'for the card', unit: 'ride', q: 'rides' },
      park:   { intro: 'Two ways to pay for downtown parking.', a: 'Plan A', b: 'Plan B', join: 'to sign up', unit: 'day', q: 'days' }
    }[ctx];
    return '<p>' + C.intro + '</p><p><b>' + C.a + ':</b> $' + fixed + ' ' + C.join + ', then $' + perA + ' per ' + C.unit +
      '.<br><b>' + C.b + ':</b> no ' + (C.join === 'to join' ? 'joining fee' : 'up-front cost') + ', $' + perB + ' per ' + C.unit +
      '.</p><p>After how many ' + C.q + ' do the two options cost exactly the same?</p>';
  }

  function stripTags(h) { return String(h || '').replace(/<[^>]*>/g, ' ').replace(/&[a-z]+;/g, ' ').replace(/\s+/g, ' ').trim(); }
  function wordCount(h) { var t = stripTags(h); return t ? t.split(' ').length : 0; }

  /* ---------- Items ---------- */
  var ITEMS = [];
  function add(o) { ITEMS.push(o); return o; }

  // Part A floor items: deliberately trivial. A miss with real effort means knowledge is below the test's floor;
  // a fast skip means effort, not knowledge.
  add({ id: 'FL1', block: 'A', type: 'num', domain: 'math', tags: ['floor'], floor: true, short: true, prompt: '<p>What is 7 + 5 ?</p>', accept: ['12'] });
  add({ id: 'FL2', block: 'A', type: 'num', domain: 'math', tags: ['floor'], floor: true, short: false, prompt: '<p>What is 10 &minus; 4 ?</p>', accept: ['6'] });
  add({ id: 'FL3', block: 'A', type: 'num', domain: 'math', tags: ['floor'], floor: true, short: true, prompt: '<p>What is 6 &times; 3 ?</p>', accept: ['18'] });
  add({ id: 'FL4', block: 'A', type: 'num', domain: 'math', tags: ['floor'], floor: true, short: false, prompt: '<p>What is 9 + 8 ?</p>', accept: ['17'] });

  // Part A: prerequisite checks. Point-blank, no hints. tags are used to match tasks to prerequisites.
  add({ id: 'A1', block: 'A', type: 'num', domain: 'math', tags: ['arith'], short: false,
    prompt: '<p>What is 36 &divide; 4 + 5 ?</p>', accept: ['14'] });
  add({ id: 'A2', block: 'A', type: 'num', domain: 'math', tags: ['frac'], short: true,
    prompt: '<p>What is ' + frac(3, 4) + ' of 80 ?</p>', accept: ['60'] });
  add({ id: 'A3', block: 'A', type: 'num', domain: 'math', tags: ['frac'], short: false,
    prompt: '<p>What is 20% of 150 ?</p>', accept: ['30'] });
  add({ id: 'A4', block: 'A', type: 'num', domain: 'math', tags: ['data'], short: true,
    prompt: '<p>This table shows pay for hours worked.</p>' + table(['Hours', 'Pay'], [['1', '$12'], ['2', '$24'], ['3', '$36'], ['4', '$48']]) +
      '<p>How much is the pay for 6 hours?</p>', accept: ['72'] });
  add({ id: 'A5', block: 'A', type: 'num', domain: 'math', tags: ['data'], short: false,
    prompt: '<p>Students picked their favorite sport.</p>' + barChart(['Soccer', 'Basketball', 'Volleyball', 'Track'], [14, 9, 4, 11], 16, 2) +
      '<p>How many more students picked Soccer than Volleyball?</p>', accept: ['10'] });
  add({ id: 'A6', block: 'A', type: 'num', domain: 'math', tags: ['pattern'], short: true,
    prompt: '<p>What number comes next?</p><p class="seq">5, 9, 13, 17, &nbsp;?</p>', accept: ['21'] });
  add({ id: 'A7', block: 'A', type: 'mc', domain: 'math', tags: ['pattern', 'linear'], short: true,
    prompt: '<p>The pattern 3, 6, 9, 12, &hellip; follows a rule. Which expression gives the <i>n</i>th number?</p>',
    options: ['n + 3', '3n', 'n<sup>3</sup>', '3 + 3n'], answer: 1 });
  add({ id: 'A8', block: 'A', type: 'num', domain: 'math', tags: ['linear'], short: true,
    prompt: '<p>Solve for <i>x</i>:</p><p class="seq">3<i>x</i> &minus; 4 = 20</p>', accept: ['8'] });
  add({ id: 'A9', block: 'A', type: 'num', domain: 'math', tags: ['stats'], short: true,
    prompt: '<p>What is the mean (average) of 5, 9, 7, 11, and 13?</p>', accept: ['9'] });

  // Part B: math investigations. Same structure, two formats: open start or forced first step.
  function tileTask(id, story, rows, nameSing, firstQ, ask, fields, ans, tags, hints) {
    add({ id: id, block: 'B', type: 'open', domain: 'math', tags: tags, short: id === 'T1' || id === 'T2', needs: ['pattern', 'linear'],
      prompt: '<p>' + story + '</p>' + table([nameSing, 'Amount'], rows) + '<p>' + ask + '</p>',
      qtype: 'num', accept: [String(ans)],
      scaffold: { prompt: firstQ, fields: fields }, hints: hints });
  }
  tileTask('T1', 'A walkway is built from square stones. Here are the first three walkways.',
    [['Walkway 1', '5 stones'], ['Walkway 2', '8 stones'], ['Walkway 3', '11 stones']], 'Walkway',
    'Before the big question, fill in the next two walkways.', 'How many stones does <b>Walkway 25</b> need?',
    [{ label: 'Walkway 4', accept: ['14'] }, { label: 'Walkway 5', accept: ['17'] }], 77, ['pattern', 'linear'],
    ['Write the number for Walkway 4. What comes after 5, 8, 11?', 'How much does the number of stones go up each time?', 'From Walkway 1 to Walkway 25, how many times does it go up?']);
  tileTask('T2', 'A banquet hall puts tables in a row. Here is how many people sit at the first three rows of tables.',
    [['1 table', '6 people'], ['2 tables', '10 people'], ['3 tables', '14 people']], 'Tables',
    'Before the big question, fill in the next two.', 'How many people can sit at <b>30 tables</b>?',
    [{ label: '4 tables', accept: ['18'] }, { label: '5 tables', accept: ['22'] }], 122, ['pattern', 'linear'],
    ['Write the number for 4 tables. What comes after 6, 10, 14?', 'How many more people does each new table add?', 'From 1 table to 30 tables, how many tables get added?']);
  tileTask('T3', 'Star-shaped signs are made from dots. Here are the first three signs.',
    [['Sign 1', '7 dots'], ['Sign 2', '12 dots'], ['Sign 3', '17 dots']], 'Sign',
    'Before the big question, fill in the next two.', 'How many dots does <b>Sign 30</b> need?',
    [{ label: 'Sign 4', accept: ['22'] }, { label: 'Sign 5', accept: ['27'] }], 152, ['pattern', 'linear'],
    ['Write the number for Sign 4. What comes after 7, 12, 17?', 'How many dots get added each time?', 'From Sign 1 to Sign 30, how many times do dots get added?']);
  tileTask('T4', 'A jar holds coins you are saving. Here is the total after each of the first three days.',
    [['Day 1', '$9'], ['Day 2', '$11'], ['Day 3', '$13']], 'Day',
    'Before the big question, fill in the next two.', 'How much is in the jar on <b>Day 45</b>? (Enter just the number.)',
    [{ label: 'Day 4', accept: ['15'] }, { label: 'Day 5', accept: ['17'] }], 97, ['pattern', 'linear'],
    ['Write the total for Day 4. What comes after 9, 11, 13?', 'How much is added each day?', 'From Day 1 to Day 45, how many days get added?']);

  // Part C: stakes. Six look-alike problems; the banner changes by form.
  var C = [
    ['C1', '<p>A shirt costs $24. It is on sale for 25% off. What is the sale price in dollars?</p>', '18'],
    ['C2', '<p>A recipe uses 3 cups of flour for 12 cookies. How many cups are needed for 20 cookies?</p>', '5'],
    ['C3', '<p>A phone plan costs $15 per month plus $0.10 for each text. What is the cost in dollars for a month with 120 texts?</p>', '27'],
    ['C4', '<p>A runner goes 6 miles in 48 minutes at a steady pace. How many minutes will 10 miles take at that pace?</p>', '80'],
    ['C5', '<p>A savings account starts with $50 and gets $15 added each week. After how many weeks will it first have at least $200?</p>', '10'],
    ['C6', '<p>A class has 28 students. ' + frac(3, 7) + ' of them walk to school. How many do <b>not</b> walk?</p>', '16']
  ];
  C.forEach(function (c, i) {
    add({ id: c[0], block: 'C', type: 'num', domain: 'math', tags: ['frac', 'arith'], needs: ['arith', 'frac'], short: i < 3,
      prompt: c[1], accept: [c[2]], confidence: true });
  });

  // Part D: choice of context vs assigned context; same break-even structure.
  var D = [
    ['D1', 24, 2, 6, 6, 'choice'], ['D2', 40, 3, 8, 8, 'bus'], ['D3', 45, 4, 9, 9, 'park'], ['D4', 60, 5, 10, 12, 'choice']
  ];
  var MENU = [['sports', 'Sports'], ['games', 'Games'], ['music', 'Music'], ['build', 'Building things']];
  D.forEach(function (d, i) {
    var o = { id: d[0], block: 'D', type: 'open', domain: 'math', tags: ['linear'], needs: ['linear', 'arith'], short: i < 2,
      qtype: 'num', accept: [String(d[4])], numbers: { fixed: d[1], perA: d[2], perB: d[3] },
      hints: ['Make a small table: 1 use, 2 uses, 3 uses, and the total cost of each option.',
        'Option A starts higher but adds less each time. Which total is bigger after 3 uses? After 6?',
        'Keep going until the two totals match.'] };
    if (d[5] === 'choice') {
      o.menu = MENU.map(function (m) { return { key: m[0], label: m[1], html: dealText(m[0], d[1], d[2], d[3]) }; });
    } else {
      o.prompt = dealText(d[5], d[1], d[2], d[3]);
    }
    add(o);
  });

  // Part F: other subjects, same open format.
  add({ id: 'F1', block: 'F', type: 'open', domain: 'science', tags: ['data'], needs: ['data'], short: true, qtype: 'num', accept: ['12'],
    prompt: '<p>A student grew the same kind of bean plant under four light levels for four weeks.</p>' +
      table(['Light level', 'Height after 4 weeks'], [['Full sun', '18 cm'], ['Partial shade', '13 cm'], ['Deep shade', '6 cm'], ['No light', '1 cm']]) +
      '<p>How many centimeters taller was the full-sun plant than the deep-shade plant?</p>',
    notesLabel: 'What do you notice? What would you test next?',
    hints: ['Find the full-sun height in the table.', 'Now find the deep-shade height.', 'Subtract.'] });
  add({ id: 'F2', block: 'F', type: 'open', domain: 'cs', tags: ['arith'], needs: ['arith'], short: true, qtype: 'num', accept: ['47'],
    prompt: '<p>Here is a short program.</p><pre class="code">x = 2\nrepeat 4 times:\n    x = x * 2 + 1\nprint x</pre><p>What number does it print?</p>',
    notesLabel: 'Trace it however you like. Write what x is after each repeat.',
    hints: ['Start with x = 2. Do the inside line once. What is x now?', 'Use that new x and do the line again.', 'Do it four times in total.'] });
  add({ id: 'F3', block: 'F', type: 'open', domain: 'reading', tags: ['reading'], needs: [], short: false, qtype: 'mc', answer: 1,
    prompt: '<p>Mara left the gate open on purpose. Her brother had been asking for weeks whether the neighbor&rsquo;s dog could visit. ' +
      'When the dog trotted into the yard and found a ball on the lawn, Mara was already holding a bowl of water. Her brother stared. &ldquo;You knew,&rdquo; he said.</p>' +
      '<p>Why was Mara holding a bowl of water?</p>',
    options: ['She was thirsty.', 'She had planned for the dog&rsquo;s visit.', 'She wanted to water the lawn.', 'She was washing the ball.'],
    notesLabel: 'What do you notice or wonder about this story?',
    hints: ['Reread the first sentence. What does &ldquo;on purpose&rdquo; tell you?', 'Who was the water for?'] });
  add({ id: 'F4', block: 'F', type: 'open', domain: 'spatial', tags: ['spatial'], needs: [], short: false, qtype: 'num', accept: ['6'],
    prompt: '<p>A 3 &times; 3 &times; 3 cube is painted red on every outside face. Then it is cut into 27 small cubes.</p>' +
      '<p>How many of the small cubes have <b>exactly one</b> red face?</p>',
    notesLabel: 'Sketch it or describe it in words.',
    hints: ['Picture one face of the big cube: a 3 &times; 3 grid of small squares.', 'Which of those 9 squares touch no edge of the big cube?', 'There are 6 faces.'] });

  // Part E: persistence ladder. Wrong answers get a neutral "try again"; unlimited attempts.
  add({ id: 'E1', block: 'E', type: 'open', domain: 'math', tags: ['pattern'], needs: ['pattern'], short: true, retry: true, level: 'easy', qtype: 'num', accept: ['42'],
    prompt: '<p>What number comes next?</p><p class="seq">2, 6, 12, 20, 30, &nbsp;?</p>',
    hints: ['Look at the gaps between neighbors.', 'The gaps are 4, 6, 8, 10&hellip;'] });
  add({ id: 'E2', block: 'E', type: 'open', domain: 'math', tags: ['linear'], needs: ['linear'], short: false, retry: true, level: 'medium', qtype: 'num', accept: ['41'],
    prompt: '<p>Three odd numbers in a row add up to 117. What is the largest of the three?</p>',
    hints: ['Try some small examples first, like 1, 3, 5.', 'The middle number is the average of the three.'] });
  add({ id: 'E3', block: 'E', type: 'open', domain: 'math', tags: ['pattern'], needs: ['pattern'], short: true, retry: true, level: 'hard', qtype: 'num', accept: ['66'],
    prompt: '<p>12 people are at a party. Everyone shakes hands with everyone else exactly once. How many handshakes happen in total?</p>',
    hints: ['Try with 2 people, then 3, then 4. Count the handshakes each time.', 'Each new person shakes hands with everyone who is already there.'] });
  add({ id: 'E4', block: 'E', type: 'expr', domain: 'math', tags: ['arith'], needs: ['arith'], short: true, retry: true, level: 'very hard',
    prompt: '<p>Put the digits 1 to 9 in order and place <b>+</b> or <b>&minus;</b> between some of them (or nothing at all, to make a bigger number) so the total is <b>100</b>.</p>' +
      '<p>Example: 12 + 34 &minus; 5 + 6789 uses the digits in order. Type your expression below, and the page will tell you what it adds up to.</p>',
    hints: ['Try gluing some digits together, like 123 or 89.', 'You need big numbers. What does 123 &minus; 45 give?'] });

  // Part G: multi-step problems. Each appears either as "trap" (just the answer choices) or "stepped" (guided steps, then the answer).
  // Wrong choices are what a student gets by skipping or botching a step; `kind` names the error for the viewer.
  function o(t, kind) { return { t: t, kind: kind }; }
  add({ id: 'G1', block: 'G', type: 'steps', domain: 'math', tags: ['multistep', 'frac'], needs: ['frac', 'arith'], short: true,
    prompt: '<p>A jacket costs $80. It is 25% off. Then a 10% tax is added to the sale price. What is the final price?</p>',
    steps: [
      { q: 'How many dollars is the 25% discount?', options: [o('$25', 'unitMix'), o('$20', 'correct'), o('$55', 'wrongOp'), o('$60', 'skipAhead')] },
      { q: 'The discount is $20. What is the sale price?', options: [o('$20', 'echo'), o('$100', 'wrongOp'), o('$60', 'correct'), o('$55', 'wrongOp')] },
      { q: 'The sale price is $60. How many dollars is the 10% tax on that price?', options: [o('$10', 'unitMix'), o('$8', 'wrongBase'), o('$66', 'skipAhead'), o('$6', 'correct')] }
    ],
    final: { q: 'What is the final price?', options: [o('$60', 'stopEarly'), o('$68', 'combine'), o('$66', 'correct'), o('$88', 'wrongBase')] } });
  add({ id: 'G2', block: 'G', type: 'steps', domain: 'math', tags: ['multistep', 'arith'], needs: ['arith'], short: true,
    prompt: '<p>A printer prints 12 pages per minute. A report is 180 pages and you need 2 copies. The printer needs 3 minutes to warm up before it starts. How many minutes until both copies are done?</p>',
    steps: [
      { q: 'How many pages are in 2 copies?', options: [o('180', 'skipStep'), o('192', 'wrongOp'), o('360', 'correct'), o('2160', 'wrongOp')] },
      { q: 'The printer must print 360 pages at 12 pages per minute. How many minutes of printing is that?', options: [o('372', 'wrongOp'), o('30', 'correct'), o('4320', 'wrongOp'), o('15', 'skipStep')] }
    ],
    final: { q: 'How many minutes until both copies are done?', options: [o('18', 'skipStep'), o('33', 'correct'), o('30', 'stopEarly'), o('363', 'wrongOp')] } });
  add({ id: 'G3', block: 'G', type: 'steps', domain: 'math', tags: ['multistep', 'arith'], needs: ['arith'], short: false,
    prompt: '<p>A garden is 12 m long and 5 m wide. A path 1 m wide goes all the way around the outside of the garden. What is the area of the path, in square meters?</p>',
    steps: [
      { q: 'With the path included, how long and wide is the outer rectangle?', options: [o('13 m by 6 m', 'misread'), o('14 m by 7 m', 'correct'), o('12 m by 5 m', 'skipStep'), o('14 m by 6 m', 'misread')] },
      { q: 'The outer rectangle is 14 m by 7 m. What is its area?', options: [o('42', 'wrongOp'), o('21', 'wrongOp'), o('88', 'misread'), o('98', 'correct')] },
      { q: 'The garden itself is 12 m by 5 m. What is its area?', options: [o('60', 'correct'), o('34', 'wrongOp'), o('17', 'wrongOp'), o('70', 'misread')] }
    ],
    final: { q: 'What is the area of the path?', options: [o('34', 'wrongOp'), o('60', 'stopEarly'), o('98', 'stopEarly'), o('38', 'correct')] } });
  add({ id: 'G4', block: 'G', type: 'steps', domain: 'math', tags: ['multistep', 'frac'], needs: ['frac', 'arith'], short: false,
    prompt: '<p>Paint is mixed 3 parts blue to 2 parts white. There are 30 liters of the mix. On Monday, half of the mix is used. How many liters of <b>blue</b> paint are used on Monday?</p>',
    steps: [
      { q: 'What fraction of the mix is blue?', options: [o(frac(2, 5), 'wrongOp'), o(frac(3, 2), 'wrongOp'), o(frac(3, 5), 'correct'), o(frac(1, 3), 'wrongOp')] },
      { q: 'Blue is ' + frac(3, 5) + ' of the mix. How many liters of blue are in all 30 liters?', options: [o('10', 'wrongOp'), o('18', 'correct'), o('12', 'wrongOp'), o('15', 'skipStep')] }
    ],
    final: { q: 'How many liters of blue paint are used on Monday?', options: [o('9', 'correct'), o('15', 'skipStep'), o('18', 'stopEarly'), o('6', 'wrongOp')] } });

  // Part K: one longer problem. Each part appears after the one before; parts are chained so the viewer can check
  // whether a student is consistent with their own earlier answers even after an arithmetic slip.
  add({ id: 'K1', block: 'K', type: 'project', domain: 'math', tags: ['multistep', 'linear'], needs: ['linear', 'arith'], short: false,
    prompt: '<p>Your club sells T-shirts. The print shop charges a <b>$60 setup fee plus $5 for each shirt</b> printed. You sell each shirt for <b>$12</b>.</p>',
    parts: [
      { key: 'a', q: 'What does it cost to print 40 shirts?', accept: ['260'], hint: 'Setup fee first, then 40 shirts at $5 each.' },
      { key: 'b', q: 'If all 40 shirts sell, how much money comes in?', accept: ['480'], hint: '40 shirts at $12 each.' },
      { key: 'c', q: 'What is the profit on those 40 shirts? (Profit = money in &minus; cost.)', accept: ['220'], hint: 'Use your answers to the first two parts.' },
      { key: 'd', q: 'You print only as many shirts as you sell. What is the smallest number of shirts you must sell to make any profit at all?', accept: ['9'], hint: 'Try 5 shirts, then 8, then 9. Compare money in with cost each time.' },
      { key: 'e', q: 'How many shirts must you print and sell to make a profit of exactly $500?', accept: ['80'], hint: 'Each shirt adds $12 and costs $5. How much profit does one shirt add after the setup fee is paid?' }
    ],
    chain: [{ target: 'c', left: 'b', op: '-', right: 'a' }] });

  // Part H: reasoning and critical thinking. Multiple choice with an optional one-sentence reason.
  function hq(id, short, prompt, opts, tags) {
    add({ id: id, block: 'H', type: 'mc', domain: 'reasoning', tags: tags || ['reasoning'], short: short, why: true,
      prompt: prompt, options: opts.map(function (x) { return x[0]; }), kinds: opts.map(function (x) { return x[1]; }),
      answer: opts.map(function (x) { return x[1]; }).indexOf('correct') });
  }
  hq('H1', true, '<p>Every student in Ms. Ortega&rsquo;s class passed the quiz. Dana did <b>not</b> pass the quiz. Which statement <b>must</b> be true?</p>',
    [['Dana is in Ms. Ortega&rsquo;s class.', 'reverseLogic'], ['Dana is not in Ms. Ortega&rsquo;s class.', 'correct'], ['Dana did not study.', 'unsupported'], ['The quiz was too hard.', 'unsupported']], ['deduction']);
  hq('H2', false, '<p>Four friends ran a race. Ana finished before Ben. Cal finished after Ben. Dee finished before Ana. Who finished <b>third</b>?</p>',
    [['Ana', 'misorder'], ['Cal', 'misorder'], ['Ben', 'correct'], ['Dee', 'misorder']], ['deduction']);
  hq('H3', true, '<p>Each card has a letter on one side and a number on the other. You can see: <b>E</b>, <b>K</b>, <b>4</b>, <b>7</b>.</p><p>The rule is: <i>&ldquo;If a card has a vowel on one side, then it has an even number on the other side.&rdquo;</i> Which cards must you turn over to find out whether the rule is broken?</p>',
    [['E and 4', 'affirmConsequent'], ['E only', 'incomplete'], ['All four cards', 'overcheck'], ['E and 7', 'correct']], ['deduction']);
  hq('H4', false, '<p>A school finds that students who eat breakfast score 10 points higher on tests than students who don&rsquo;t. A board member says, &ldquo;Let&rsquo;s give every student free breakfast to raise test scores.&rdquo; What is the best reason to be cautious about that conclusion?</p>',
    [['Ten points is too small to matter.', 'dismiss'], ['Students who eat breakfast may also differ in other ways, like sleep or home routines.', 'correct'], ['Test scores can&rsquo;t really be measured.', 'dismiss'], ['Breakfast is unhealthy for most students.', 'unsupported']], ['critical']);
  hq('H5', true, '<p>A student solves 2(<i>x</i> + 3) = 14 like this:</p><pre class="code">Step 1:  2x + 3 = 14\nStep 2:  2x = 11\nStep 3:  x = 5.5</pre><p>Which step contains the <b>first</b> mistake?</p>',
    [['Step 3', 'laterStep'], ['Step 1', 'correct'], ['Step 2', 'laterStep'], ['There is no mistake.', 'noneFound']], ['critical']);
  hq('H6', false, '<p>Each of two people either always tells the truth or always lies. Ava says, &ldquo;Ben is a liar.&rdquo; Ben says, &ldquo;Ava and I are both truth-tellers.&rdquo; Who is telling the truth?</p>',
    [['Ben tells the truth; Ava lies.', 'misdeduce'], ['Both are liars.', 'misdeduce'], ['Both are truth-tellers.', 'misdeduce'], ['Ava tells the truth; Ben lies.', 'correct']], ['deduction']);

  // Optional extras
  add({ id: 'X1', block: 'X', type: 'mc', domain: 'logic', tags: [], short: true, answer: 2,
    prompt: '<p>Three boxes are labeled <b>Apples</b>, <b>Oranges</b>, and <b>Mixed</b>. Every label is wrong. You may take one fruit out of one box without looking inside. Which box should you pick from to work out all three?</p>',
    options: ['Apples', 'Oranges', 'Mixed'] });
  add({ id: 'X2', block: 'X', type: 'num', domain: 'math', tags: [], short: true, accept: ['5050'],
    prompt: '<p>What is 1 + 2 + 3 + &hellip; + 100 ?</p>' });
  add({ id: 'X3', block: 'X', type: 'num', domain: 'cs', tags: [], short: false, accept: ['8'],
    prompt: '<p>How many different 3-letter strings can you make using only the letters A and B? (Repeats allowed, like AAB.)</p>' });
  add({ id: 'X4', block: 'X', type: 'num', domain: 'science', tags: [], short: false, accept: ['32'],
    prompt: '<p>A sheet of paper is folded in half 5 times. How many layers thick is the folded stack?</p>' });

  // Reading checks (not graded; embedded instruction)
  var READ = [
    { id: 'R1', pos: 'early', pass: 3, options: ['Quiet', 'Music', 'With friends', 'Purple'],
      prompt: '<p>Students study in lots of different ways. Some like quiet, some like music, and some work best with friends nearby. Think about which one fits you. Now look at the four buttons below. Whatever you would normally choose, do not pick that. To show you have read to the end of this paragraph, pick the button that says <b>Purple</b> instead.</p>' },
    { id: 'R2', pos: 'middle', pass: 1, options: ['Setting up tables', 'Making posters', 'Selling tickets', 'Cleaning up'],
      prompt: '<p>Imagine you are helping plan a school fundraiser. There are many jobs to do: setting up tables, making posters, selling tickets, and cleaning up afterward. You could say which job you like best, but that is not what this screen wants. Here is the real instruction: ignore your favorite and choose the <b>second</b> option from the top.</p>' },
    { id: 'R3', pos: 'late', pass: 3, options: ['Tired', 'Fine', 'Bored', 'Skip ahead'],
      prompt: '<p>Long tests can be tiring, and that is normal. Please do not click the first option you see. Instead, read this whole screen, because the answer it wants is the button labeled <b>Skip ahead</b>. The rest of this paragraph is only about how people feel after working for a while: some get restless, some get focused, and some just want it to be over.</p>' }
  ];
  READ.forEach(function (r) {
    add({ id: r.id, block: 'R', type: 'mc', domain: 'reading', tags: [], readcheck: true, pos: r.pos, short: r.id !== 'R3' ? true : true,
      prompt: r.prompt, options: r.options, answer: r.pass });
  });

  var SURVEY = {
    likert: [
      ['S1', 'When I don’t know how to start a math problem, I wait for someone to show me.'],
      ['S2', 'I would rather skip a problem than risk getting it wrong.'],
      ['S3', 'When I get stuck, I try a different approach before asking for help.'],
      ['S4', 'I start more easily when I can choose the situation a problem is about.'],
      ['S5', 'I usually finish problems even when they are hard.'],
      ['S6', 'Most math problems feel pointless to me.'],
      ['S7', 'I feel nervous when my teacher can see my work in progress.'],
      ['S8', 'Starting is the hardest part for me.']
    ],
    scale: ['Strongly disagree', 'Disagree', 'Not sure', 'Agree', 'Strongly agree'],
    why: [
      ['comprehension', 'I’m not sure what the question is asking'],
      ['entry', 'I understand it but don’t know what to do first'],
      ['fear', 'I’m afraid of getting it wrong'],
      ['value', 'It feels pointless or boring'],
      ['state', 'I’m tired or distracted'],
      ['identity', 'I don’t think I’m a math person'],
      ['none', 'I usually do start']
    ],
    whyPrompt: 'When I don’t start a problem, it is usually because (pick up to three):',
    openPrompt: 'Anything you want your teacher to know about how you work on problems? (Optional)'
  };

  /* ---------- Forms ---------- */
  // Each condition appears at early, middle and late positions across the two forms, so order and difficulty wash out.
  var FORMS = {
    A: {
      B: { T1: 'open', T2: 'forced', T3: 'forced', T4: 'open' },
      C: { C1: 'low', C2: 'teacher', C3: 'credit', C4: 'credit', C5: 'teacher', C6: 'low' },
      D: { D1: 'choice', D2: 'assigned', D3: 'assigned', D4: 'choice' },
      G: { G1: 'trap', G2: 'stepped', G3: 'stepped', G4: 'trap' }
    },
    B: {
      B: { T1: 'forced', T2: 'open', T3: 'open', T4: 'forced' },
      C: { C1: 'credit', C2: 'teacher', C3: 'low', C4: 'low', C5: 'teacher', C6: 'credit' },
      D: { D1: 'assigned', D2: 'choice', D3: 'choice', D4: 'assigned' },
      G: { G1: 'stepped', G2: 'trap', G3: 'trap', G4: 'stepped' }
    }
  };

  var BLOCKS = {
    A: { title: 'Warm-up', text: 'Short questions with no tricks. If you don’t know one, “I don’t know” is a useful answer.' },
    B: { title: 'Investigations', text: 'Each one starts with a pattern. Use the work area however you like. If you get stuck, press “I’m stuck” for a nudge.' },
    C: { title: 'Quick problems', text: 'Each problem has a short note at the top telling you how it will be used. Read it, then answer.' },
    D: { title: 'Which deal is better?', text: 'Some of these let you pick the situation the problem is about.' },
    G: { title: 'Multi-step problems', text: 'Some of these give you only answer choices. Others walk you through the steps first. Either way, work it out; don\u2019t guess.' },
    K: { title: 'One longer problem', text: 'This one has five parts. Each part builds on the ones before it, so do them in order.' },
    H: { title: 'Reasoning', text: 'These are about thinking carefully, not calculating. You can add a sentence about why you chose your answer.' },
    F: { title: 'Different subjects', text: 'Same kind of work, other topics: science, code, reading, and spatial thinking.' },
    E: { title: 'Getting harder', text: 'These get harder as you go. The last one is very hard, and many adults can’t finish it quickly. You decide when to move on.' }
  };

  var ORDER = ['A', 'B', 'C', 'D', 'G', 'K', 'H', 'F', 'E'];
  var READ_AFTER = { A: 'R1', C: 'R2', E: 'R3' };

  function byId(id) { for (var i = 0; i < ITEMS.length; i++) if (ITEMS[i].id === id) return ITEMS[i]; return null; }

  // Returns the ordered list of screens for a form ('A'|'B') and length ('full'|'short').
  // sel: optional string of block letters to run in one sitting, e.g. 'ABC'. Add X for the optional extras and S for the survey.
  // With no sel everything runs. Reading checks: first at the start, last before extras, one in the middle when 3+ blocks run.
  function sequence(form, len, sel) {
    var short = len === 'short', out = [], F = FORMS[form] || FORMS.A;
    function keep(it) { return !short || it.short; }
    var letters = sel ? String(sel).toUpperCase().split('') : ORDER.concat(['X', 'S']);
    var chosen = ORDER.filter(function (b) { return letters.indexOf(b) > -1; });
    var midAt = chosen.length >= 3 ? Math.floor(chosen.length / 2) - 1 : -1;
    if (chosen.length) out.push({ kind: 'item', id: 'R1', block: 'R' });
    chosen.forEach(function (b, i) {
      var items = ITEMS.filter(function (it) { return it.block === b && keep(it); });
      out.push({ kind: 'intro', block: b });
      items.forEach(function (it) {
        out.push({ kind: 'item', id: it.id, block: b, cond: (F[b] && F[b][it.id]) || null });
      });
      if (i === midAt) out.push({ kind: 'item', id: 'R2', block: 'R' });
    });
    if (chosen.length) out.push({ kind: 'item', id: 'R3', block: 'R' });
    if (letters.indexOf('X') > -1) out.push({ kind: 'extras', ids: ITEMS.filter(function (it) { return it.block === 'X' && keep(it); }).map(function (it) { return it.id; }) });
    if (letters.indexOf('S') > -1) out.push({ kind: 'survey' });
    return out;
  }

  /* ---------- Checking ---------- */
  function toNumber(v) {
    var s = String(v == null ? '' : v).replace(/[−–]/g, '-').replace(/,/g, '').toLowerCase();
    var toks = s.match(/-?\d+(?:\.\d+)?(?:\s*\/\s*\d+)?/g);
    if (!toks) return NaN;
    var t = toks[toks.length - 1].replace(/\s/g, '');
    if (t.indexOf('/') > -1) { var p = t.split('/'); return parseFloat(p[0]) / parseFloat(p[1]); }
    return parseFloat(t);
  }

  function evalDigits(raw) {
    var s = String(raw || '').replace(/[−–]/g, '-').replace(/\s+/g, '');
    if (!s) return { ok: false, reason: 'Type an expression first.' };
    if (!/^[0-9+\-]+$/.test(s)) return { ok: false, reason: 'Use only the digits 1 to 9, plus signs, and minus signs.' };
    if (!/^\d/.test(s) || !/\d$/.test(s)) return { ok: false, reason: 'Start and end with a digit.' };
    if (s.replace(/[+\-]/g, '') !== '123456789') return { ok: false, reason: 'The digits must appear as 1 2 3 4 5 6 7 8 9, in that order, each once.' };
    if (/[+\-]{2}/.test(s)) return { ok: false, reason: 'Put only one sign between numbers.' };
    var total = 0, re = /([+\-]?)(\d+)/g, m;
    while ((m = re.exec(s))) total += (m[1] === '-' ? -1 : 1) * parseInt(m[2], 10);
    return { ok: true, value: total };
  }

  // value: number text for num/open-num, option index for mc, text for expr.
  function check(item, value) {
    if (item.type === 'steps') return item.final.options[Number(value)] ? item.final.options[Number(value)].kind === 'correct' : false;
    if (item.type === 'mc' || item.qtype === 'mc') return Number(value) === item.answer;
    if (item.type === 'expr') { var r = evalDigits(value); return r.ok && r.value === 100; }
    var n = toNumber(value);
    if (isNaN(n)) return false;
    return (item.accept || []).some(function (a) { return Math.abs(toNumber(a) - n) < 1e-9; });
  }

  function rapidMs(item, extraWords) {
    var words = wordCount(item.prompt || (item.menu && item.menu[0].html) || '') + (item.options ? wordCount(item.options.join(' ')) : 0) + (extraWords || 0);
    return CONFIG.rapidBaseMs + CONFIG.rapidPerWordMs * words;
  }

  function dealPrompt(item, key) {
    if (item.prompt) return item.prompt;
    var m = item.menu.filter(function (x) { return x.key === key; })[0];
    return m ? m.html : '';
  }

  return {
    CONFIG: CONFIG, ITEMS: ITEMS, FORMS: FORMS, BLOCKS: BLOCKS, ORDER: ORDER, SURVEY: SURVEY, MENU: MENU,
    byId: byId, sequence: sequence, check: check, evalDigits: evalDigits, toNumber: toNumber,
    rapidMs: rapidMs, wordCount: wordCount, stripTags: stripTags, dealPrompt: dealPrompt, dealText: dealText
  };
});
