# tenSHion Diagnostic

Alleviate the tension between students and teachers. A forward-only set of math and reasoning problems that shows
whether a student **can't start**, **won't start**, or **doesn't yet know enough to start**, and whether they are reading
or rushing. Version 1.0.2.

Everything is plain HTML, CSS and JavaScript with no runtime dependencies and no server. Build needs only Python 3.

## Use it without building

`dist/site/` is the finished site. Open `dist/site/index.html`, or upload the whole folder to any web host.

| File | What it is |
|---|---|
| `index.html` | Landing page with a student link builder |
| `test.html` | The student test (forward-only, resumes on refresh) |
| `viewer.html` | Teacher results viewer: classifies students, compares conditions, exports CSV |
| `print.html` | Printable booklet builder (Form A or B, choose sections, `?key=1` for the answer key) |
| `booklet-formA.pdf`, `booklet-formB.pdf`, `booklet-key.pdf` | Ready-to-print booklets |

`dist/artifact/` has the landing, test and viewer without the document wrapper, for publishing as claude.ai artifacts.

## Build

```
python3 build.py
```

Reads `src/` and `site.json`, writes `dist/site/` and `dist/artifact/`. Python standard library only.

`site.json` sets where the landing page sends people. `static` is for the self-hosted folder (relative links work as is).
`artifact` holds the claude.ai links. Change them if you republish under new links.

## Layout

```
src/bank.js        item bank, forms A/B, settings (title, stakes banners, instructions, version, submitUrl)
src/test.html      student test UI and engine
src/analysis.js    merging results and the classification rules
src/viewer.html    results viewer
src/print.html     printable booklet builder
src/landing.html   landing page (tokens __TEST_URL__, __VIEWER_URL__, __SHARE_NOTE__ come from site.json)
src/sample-codes.json   the viewer's built-in sample class (made by `npm run sample`)
site.json          link targets for the landing page
build.py           inlines the JS into each page and writes dist/
tools/make_logo.py generates the animated logo SVGs into brand/
brand/             animated and static logo SVGs, app-icon mark
src/theme.css      the shared palette and chalk/dust styles; src/defs.html is the chalk filter
docs/TEACHER-GUIDE.md   how to run it in a class and read the results
tests/             node tests (see below)
```

## Link options for students

Options go in the address as a query (`test.html?form=B&len=short`) or, on hosted pages that drop queries, as hash
tokens (`test.html#form-B_len-short`).

| Option | Query | Hash token |
|---|---|---|
| Form A or B (default: assigned by name) | `form=A` | `form-A` |
| Short version, about 25 minutes | `len=short` | `len-short` |
| One sitting: `ABC`, `DGKH`, or `FEXS` | `blocks=ABC` | `blocks-ABC` |
| Prefill class | `class=P4` | `class-P4` |
| Teacher preview bar | `teacher=1` | `teacher` |
| Clear a saved session | `reset=1` | `reset` |

## Settings you will likely change

All in `CONFIG` at the top of `src/bank.js`:

- `stakes`: the three banner texts. **Keep only wording you will honor.** The "counts" banner tells students the item counts toward participation points.
- `instructions`, `title`, `submitHelp`: what students read.
- `submitUrl`: an optional endpoint (Apps Script, Cloudflare Worker) that accepts a JSON POST so results arrive without students handing in files. Leave empty to use file download and copy-code only.
- `version`, `released`: see below.

## Versioning

Semantic: bump **major** when scoring or what an item means changes (old and new results should not be pooled), **minor** when items or screens are added, **patch** for wording, layout and fixes. Every results file records `version`; the viewer lists the versions it has loaded and warns when major versions differ. After changing `version` in `src/bank.js` also update `package.json` and add a changelog entry in `src/landing.html`.

## Tests

```
npm install
npx playwright install chromium
npm test
```

`npm test` builds, checks every answer key, drives the real test in Chromium with five scripted student profiles, checks that the
viewer classifies them as intended, and tests forward-only behavior, resume, the stakes banner by form, hash links, the results code round trip, and phone layout.

- `npm run check` runs the answer-key and analysis checks only (no browser).
- `npm run sample` rebuilds the viewer's sample class from the latest simulated runs.
- `npm run pdfs` regenerates the three booklet PDFs into `dist/site/` (needs Chromium).
- `npm run logo` regenerates `brand/` (needs `pip install fonttools brotli`).

The simulated students are scripted, so the classification tests show the rules do what they were written to do. They do not show the cutoffs are right for real students. Run one class and calibrate.

## Publishing as claude.ai artifacts

Publish `dist/artifact/test.html` and `viewer.html` with the downloads capability, and `landing.html` with the three booklet PDFs
alongside it. Hosted pages cannot read a `?query`, send results to you, or open a print dialog, so students save a file or copy the results code, and `print.html` stays a file.

## Brand and style

The palette is "Eraser dust": a warm graphite board with dusty chalk colors, and a dusty desk-paper light mode. Everything is driven by `src/theme.css`, which `build.py` inserts into the test, viewer and landing page; edit the tokens there and rebuild. `src/defs.html` holds the SVG chalk filter that roughens big type and cords, and the `.dust` class adds the grain and haze on the board-colored bands. To turn the texture off everywhere, set `--chalk: none;` in `theme.css` and delete the `.dust::before` rule.

`brand/` holds the animated logos. In `tenshion-logo.svg` the letters on one side of SH stretch while the other side bunches up, it swings the other way, and settles while the cord goes slack.

- `tenshion-logo.svg`: adaptive (dusty paper by day, the board in dark mode), chalked
- `tenshion-logo-clean.svg`: same without the chalk texture, for small sizes
- `tenshion-logo-on-board.svg`: on its own graphite board with grain
- `tenshion-logo-loop.svg`: replays with a re-tension
- `tenshion-logo-static.svg`, `tenshion-mark-static.svg`: no animation
- `tenshion-mark.svg`: SH app icon

Regenerate with `npm run logo` after changing the colors at the top of `tools/make_logo.py` (keep them in step with `theme.css`). The wordmark outlines come from Archivo (SIL Open Font License, `tools/fonts/OFL-Archivo.txt`).

