#!/usr/bin/env python3
"""Generate the animated tenSHion logo SVGs in brand/.

Idea: tension. "SH" is the knot in the middle of an elastic cord and it is pulled back and forth. The letters on the
side it moves away from stretch wide, the letters on the side it moves toward bunch up, then it swings the other way,
loses energy and comes to rest in the middle, where the cord goes slack.

The wordmark is drawn from real Archivo outlines (SIL Open Font License) at several widths, so the letters morph
between condensed (wdth 62), normal (100) and extended (125) inside a standalone SVG with no font dependency.

    pip install fonttools brotli
    python3 tools/make_logo.py
"""
import math, pathlib, re
from fontTools.ttLib import TTFont
from fontTools.varLib import instancer
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
from fontTools.pens.boundsPen import BoundsPen

ROOT = pathlib.Path(__file__).resolve().parent.parent
FONT = ROOT / 'tools' / 'fonts' / 'archivo-latin-standard-normal.woff2'
OUT = ROOT / 'brand'
OUT.mkdir(exist_ok=True)

# Eraser dust palette (keep in step with src/theme.css)
INK, SH_LIGHT, CORD_LIGHT, PAPER = '#292826', '#A4503A', '#B8603F', '#E6E4DF'   # on dusty paper
CHALK, PINK, PEACH, BOARD, BOARD_DEEP = '#EEEBE2', '#E6B3AB', '#E3A67F', '#363532', '#1F1E1C'   # on the board
WGHT = 800
DECAY, OMEGA = 1.3, 7.0             # s(t) = exp(-DECAY t) cos(OMEGA t): the swing
HALF = math.pi / OMEGA              # time between extremes
SETTLE = 2.4                        # comes to rest here
SINE = '.37 0 .63 1'                # ease between an extreme and the middle


def num(v):
    return ('%.1f' % v).rstrip('0').rstrip('.')


def wmap(s):
    """Pull s in [-1, 1] -> font width. Stretching goes to 125, bunching to 62."""
    return 100 + (25 * s if s >= 0 else 38 * s)


_cache = {}
def instance(wdth):
    wdth = round(wdth, 1)
    if wdth not in _cache:
        _cache[wdth] = instancer.instantiateVariableFont(TTFont(str(FONT)), {'wght': WGHT, 'wdth': wdth}, inplace=False)
    return _cache[wdth]


def lay(state, spec, extra, shift, size, base):
    """state=(w_left, w_right). Returns ([d per group], xmin, xmax). Left group at w_left, right at w_right, middle at 100."""
    x = shift; ds = []; xmin, xmax = 1e9, -1e9
    for gi, (chars, role) in enumerate(spec):
        wd = {'a': state[0], 'm': 100, 'b': state[1]}[role]
        f = instance(wd); gs = f.getGlyphSet(); cmap = f.getBestCmap(); sc = size / f['head'].unitsPerEm
        d = ''
        for ch in chars:
            g = gs[cmap[ord(ch)]]; tr = (sc, 0, 0, -sc, x, base)
            pen = SVGPathPen(gs, ntos=num); g.draw(TransformPen(pen, tr)); d += pen.getCommands()
            bp = BoundsPen(gs); g.draw(TransformPen(bp, tr))
            if bp.bounds: xmin = min(xmin, bp.bounds[0]); xmax = max(xmax, bp.bounds[2])
            x += g.width * sc - 0.02 * size + extra
        ds.append(d)
    return ds, xmin, xmax


def timeline(mode):
    """Keyframes as (t, s) for the letters, plus total duration. s=+1: pulled right (left letters stretched)."""
    ks = []
    for j in range(5):                               # extremes
        t = j * HALF; s = math.exp(-DECAY * t) * (1 if j % 2 == 0 else -1)
        ks.append((t, s))
        if j < 4: ks.append((t + HALF / 2, 0.0))     # pass through the middle
    ks.append((SETTLE, 0.0))
    T = SETTLE
    if mode == 'loop':
        ks.append((SETTLE + 2.4, 0.0)); ks.append((SETTLE + 2.4 + 1.2, 1.0)); T = SETTLE + 3.6
    return ks, T


def splines(ks, mode):
    out = []
    for i in range(len(ks) - 1):
        (t0, s0), (t1, s1) = ks[i], ks[i + 1]
        if mode == 'loop' and i == len(ks) - 2: out.append('.4 0 .6 1')
        elif s0 == s1 == 0.0 and t1 - t0 > 1.0: out.append('0 0 1 1')
        elif i == len(ks) - 2 or (t1 - t0) > HALF: out.append('.2 .7 .2 1')
        else: out.append(SINE)
    return out


def cord_frames(T, mode, y0, sag_rest, x0, x1, step):
    out = []; t = 0.0
    while t <= T + 1e-9:
        if t <= SETTLE:
            s = math.exp(-DECAY * t) * math.cos(OMEGA * t); sag = sag_rest * (1 - s * s) if t < SETTLE else sag_rest
        elif t <= SETTLE + 2.4: sag = sag_rest
        else:
            q = (t - SETTLE - 2.4) / 1.2; q = q * q * (3 - 2 * q); sag = sag_rest * (1 - q)
        out.append((t / T, 'M%s %s Q %s %s %s %s' % (num(x0), num(y0), num((x0 + x1) / 2), num(y0 + 2 * sag), num(x1), num(y0))))
        t += step
    return out


def build(kind, variant, chalk=True):
    word = kind == 'word'; mode = 'loop' if variant == 'loop' else 'once'; static = variant == 'static'
    if word:
        spec = [('ten', 'a'), ('SH', 'm'), ('ion', 'b')]; cls = ['t', 's', 't']
        size, base, left, vpad, H = 170, 190, 44, 44, 310
        y0, sag_rest, sw, ar = base + 46, 34, 7, 9
    else:
        spec = [('S', 'a'), ('H', 'b')]; cls = ['m', 'm']
        size, base, left, vpad, H = 260, 300, None, 0, 512
        y0, sag_rest, sw, ar = base + 70, 32, 11, 13
    ks, T = timeline(mode)
    states = [(wmap(s), wmap(-s)) for _, s in ks]
    n = sum(len(c) for c, _ in spec)
    # natural ink width of each state; the widest sets the span so the ends of the cord never move
    nat = [lay(st, spec, 0, 0, size, base) for st in states]
    target = max(r[2] - r[1] for r in nat)
    if word: W = int(math.ceil(left + target + vpad))
    else: W = 512
    x_left = left if word else (W - target) / 2
    laid = []
    for st, r in zip(states, nat):
        extra = (target - (r[2] - r[1])) / (n - 1)
        ds, a, b = lay(st, spec, extra, x_left - r[1], size, base)
        laid.append(ds)
    for gi in range(len(spec)):                                   # morph compatibility
        seqs = {tuple(re.findall('[A-Za-z]', ds[gi])) for ds in laid}
        assert len(seqs) == 1, 'outlines are not morph compatible'
    x0, x1 = x_left, x_left + target

    board = (variant == 'board') or not word          # the app-icon mark and the board variant carry their own background
    flt = ' filter="url(#chalk)"' if chalk else ''
    defs = ''
    if chalk:
        defs += ('<filter id="chalk" filterUnits="userSpaceOnUse" x="-100" y="-100" width="%d" height="%d">'
                 '<feTurbulence type="fractalNoise" baseFrequency="0.03" numOctaves="2" seed="3" result="warp"/>'
                 '<feDisplacementMap in="SourceGraphic" in2="warp" scale="%s" result="rough"/>'
                 '<feTurbulence type="fractalNoise" baseFrequency="0.7" numOctaves="2" seed="9" result="g"/>'
                 '<feColorMatrix in="g" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 -1.1 1.56" result="m"/>'
                 '<feComposite in="rough" in2="m" operator="in"/></filter>' % (W + 200, H + 200, '2.2' if word else '3.4'))
    if board and chalk:
        defs += ('<filter id="grain" x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency=".85" numOctaves="3" seed="4"/>'
                 '<feColorMatrix type="matrix" values="0 0 0 0 1  0 0 0 0 1  0 0 0 0 .96  0 0 0 1.2 -.5"/></filter>'
                 '<radialGradient id="haze1" cx=".18" cy=".08" r="1.1"><stop offset="0" stop-color="#fff" stop-opacity=".2"/><stop offset=".6" stop-color="#fff" stop-opacity="0"/></radialGradient>'
                 '<radialGradient id="haze2" cx=".92" cy="1" r=".9"><stop offset="0" stop-color="#fff" stop-opacity=".13"/><stop offset=".65" stop-color="#fff" stop-opacity="0"/></radialGradient>')
    if word and not board:   # adaptive: dusty paper by day, the board by night
        style = ('.t{fill:%s}.s{fill:%s}.c{stroke:%s}.a{fill:%s;stroke:%s}'
                 '@media (prefers-color-scheme:dark){.t{fill:%s}.s{fill:%s}.c{stroke:%s}.a{fill:%s;stroke:%s}}') % (INK, SH_LIGHT, CORD_LIGHT, PAPER, INK, CHALK, PINK, PEACH, BOARD_DEEP, CHALK)
        bg = ''
    elif word:
        style = '.t{fill:%s}.s{fill:%s}.c{stroke:%s}.a{fill:%s;stroke:%s}' % (CHALK, PINK, PEACH, BOARD, CHALK)
    else:
        style = '.m{fill:%s}.c{stroke:%s}.a{fill:%s;stroke:%s}' % (PINK, PEACH, BOARD, CHALK)
    if board:
        rx = 28 if word else 112
        bg = '<rect width="%d" height="%d" rx="%d" fill="%s"/>' % (W, H, rx, BOARD)
        if chalk:
            bg += ('<g opacity=".22"><rect width="%d" height="%d" rx="%d" filter="url(#grain)"/></g>'
                   '<rect width="%d" height="%d" rx="%d" fill="url(#haze1)"/><rect width="%d" height="%d" rx="%d" fill="url(#haze2)"/>') % (W, H, rx, W, H, rx, W, H, rx)

    rest_i = max(i for i, (t, s) in enumerate(ks) if abs(t - SETTLE) < 1e-9)
    shown = rest_i if static else 0
    kt = ';'.join('%.4f' % (t / T) for t, _ in ks); sp = ';'.join(splines(ks, mode))
    paths = []
    for gi, c in enumerate(cls):
        d0 = laid[shown][gi]; anim = ''
        if not static:
            rc = ' repeatCount="indefinite"' if mode == 'loop' else ' fill="freeze"'
            anim = '<animate attributeName="d" dur="%ss" begin="0s" calcMode="spline" keyTimes="%s" keySplines="%s" values="%s"%s/>' % (num(T), kt, sp, ';'.join(ds[gi] for ds in laid), rc)
        paths.append('<path class="%s" d="%s">%s</path>' % (c, d0, anim))

    fr = cord_frames(T, mode, y0, sag_rest, x0, x1, 0.05 if mode == 'once' else 0.1)
    cd = fr[-1][1] if (static or mode == 'once' and False) else fr[0][1]
    if static: cd = cord_frames(SETTLE, 'once', y0, sag_rest, x0, x1, SETTLE)[-1][1]
    cord = '<path class="c" fill="none" stroke-width="%d" stroke-linecap="round" d="%s">' % (sw, cd)
    if not static:
        rc = ' repeatCount="indefinite"' if mode == 'loop' else ' fill="freeze"'
        cord += '<animate attributeName="d" dur="%ss" begin="0s" calcMode="linear" keyTimes="%s" values="%s"%s/>' % (num(T), ';'.join('%.4f' % f[0] for f in fr), ';'.join(f[1] for f in fr), rc)
    cord += '</path>'
    anchors = ''.join('<circle class="a" cx="%s" cy="%s" r="%d" stroke-width="%d"/>' % (num(x), num(y0), ar, 4 if word else 5) for x in (x0, x1))
    label = 'tenSHion Diagnostic' if word else 'tenSHion'
    art = '<g%s>%s\n%s</g>\n%s' % (flt, '\n'.join(paths), cord, anchors)
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" width="%d" height="%d" role="img" aria-labelledby="t">\n<title id="t">%s</title>\n%s<style>%s</style>\n%s\n%s\n</svg>\n'
            % (W, H, W, H, label, ('<defs>%s</defs>\n' % defs) if defs else '', style, bg, art))


if __name__ == '__main__':
    files = {   # name: (kind, variant, chalked)
        'tenshion-logo.svg': ('word', 'adaptive', True),
        'tenshion-logo-clean.svg': ('word', 'adaptive', False),     # no chalk filter: use below ~200px wide or in print
        'tenshion-logo-on-board.svg': ('word', 'board', True),
        'tenshion-logo-loop.svg': ('word', 'loop', True),
        'tenshion-logo-static.svg': ('word', 'static', False),
        'tenshion-mark.svg': ('mark', 'once', True),
        'tenshion-mark-static.svg': ('mark', 'static', False),
    }
    for name, (kind, variant, chalk) in files.items():
        s = build(kind, variant, chalk)
        (OUT / name).write_text(s, encoding='utf-8')
        print('wrote brand/%s (%d KB)' % (name, len(s) // 1024 or 1))
